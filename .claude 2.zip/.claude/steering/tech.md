# Technology Stack - SmartSub

## Architecture Overview
SmartSub is built as a hybrid Electron + Next.js desktop application, combining the power of web technologies with native desktop capabilities for optimal performance and user experience.

## Core Technologies

### Desktop Framework
- **Electron 30.1.0**: Cross-platform desktop application framework
- **Nextron 9.1.0**: Electron + Next.js integration framework
- **Process Architecture**: Main process (Node.js) + Renderer process (Next.js)

### Frontend Stack
- **Next.js 14.2.4**: React framework with SSG capabilities
- **React 18.2.0**: UI library with hooks pattern
- **TypeScript 5.4.5**: Static typing with strict mode enabled
- **Tailwind CSS 3.4.3**: Utility-first CSS framework
- **Radix UI**: Headless UI components with shadcn/ui design system

### AI & Media Processing
- **Whisper.cpp**: Speech recognition engine with native Node.js bindings
- **FFmpeg**: Audio/video processing and format conversion
- **Hardware Acceleration**:
  - CUDA 11.8.0/12.2.0/12.4.1 (Windows/Linux)
  - Core ML (macOS M-series chips)

### Translation Services
- **Multi-Provider Support**:
  - Baidu Translation API
  - Microsoft Translator
  - Volcano Engine Translation
  - DeepLX (local DeepL)
  - Ollama (local LLM)
  - OpenAI-style APIs (DeepSeek, Azure OpenAI)
  - DeerAPI (aggregation platform)

### State Management & Storage
- **Electron Store 8.2.0**: Persistent application configuration
- **React Hook Form 7.51.4**: Form state management with Zod validation
- **Context API**: React state management for UI components

### Development Tools
- **Prettier 3.5.3**: Code formatting with custom configuration
- **Husky 9.1.7**: Git hooks for pre-commit quality checks
- **Lint-staged 15.5.2**: Run linters on staged files
- **Electron Builder 24.13.3**: Application packaging and distribution

## Architecture Patterns

### Process Communication
- **IPC (Inter-Process Communication)**: Secure communication between main and renderer processes
- **Preload Scripts**: Safe API exposure to renderer process
- **Event-Driven**: Async task processing with progress tracking

### Component Architecture
- **Atomic Design**: Reusable UI components with consistent patterns
- **Custom Hooks**: Encapsulated logic for IPC communication, state management
- **TypeScript Interfaces**: Strongly typed contracts for all data structures

### File Organization
```
main/           # Electron main process
├── background.ts       # Main entry point
├── helpers/           # Core business logic
├── service/          # Translation service implementations
└── translate/        # Translation orchestration

renderer/       # Next.js renderer process
├── components/       # React components
├── hooks/           # Custom React hooks
├── pages/           # Next.js pages
└── public/locales/  # Internationalization

types/          # Shared TypeScript definitions
extraResources/ # Native addons and models
```

## Technical Constraints

### Performance Requirements
- **Real-time Processing**: Subtitle generation should approach real-time speeds
- **Memory Efficiency**: Support for large audio/video files without memory leaks
- **Concurrent Processing**: Configurable batch processing with resource management

### Platform Compatibility
- **Windows**: x64 with optional CUDA acceleration
- **macOS**: Intel (x64) and Apple Silicon (arm64) with Core ML
- **Linux**: x64 with optional CUDA acceleration

### Security Considerations
- **Local Processing**: No external data transmission for core functionality
- **Secure IPC**: Sandboxed renderer process with controlled API access
- **File System Security**: Validated file operations with proper error handling

## Integration Requirements

### Third-Party Services
- **Translation APIs**: RESTful integration with error handling and rate limiting
- **Model Distribution**: Automated download and verification of Whisper models
- **Update Mechanism**: Electron-updater for automatic application updates

### Hardware Integration
- **GPU Acceleration**: Dynamic detection and utilization of available hardware
- **Audio/Video Codecs**: Support for common media formats through FFmpeg
- **File System**: Cross-platform file operations with proper permissions

## Development Standards

### Code Quality
- **TypeScript Strict Mode**: Comprehensive type checking
- **ESLint + Prettier**: Automated code formatting and linting
- **Git Hooks**: Pre-commit quality checks and formatting

### Testing Strategy
- **Unit Testing**: Component and utility function testing
- **Integration Testing**: IPC communication and service integration
- **Manual Testing**: Cross-platform compatibility verification

### Deployment Pipeline
- **GitHub Actions**: Automated building and release creation
- **Multi-Platform Builds**: Windows, macOS, and Linux distributions
- **Asset Optimization**: Model packaging and distribution optimization

## Technology Decisions

### Framework Choice: Electron + Next.js
- **Pros**: Cross-platform, web technology familiarity, rich ecosystem
- **Cons**: Memory overhead, larger application size
- **Rationale**: Rapid development, UI flexibility, extensive library support

### AI Engine: Whisper.cpp
- **Pros**: Local processing, hardware acceleration, proven accuracy
- **Cons**: Model size, initial setup complexity
- **Rationale**: Privacy requirements, performance, offline capability

### UI Framework: React + Tailwind + Radix
- **Pros**: Component reusability, accessibility, consistent design
- **Cons**: Bundle size, learning curve
- **Rationale**: Developer productivity, maintainability, user experience