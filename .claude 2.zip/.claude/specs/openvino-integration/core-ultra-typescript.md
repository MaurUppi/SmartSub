在 **硬件识别** 环节用 TypeScript 明确“是否为 Intel Core Ultra 处理器”，最佳实践可拆成两步：  

1. **在 Node/Electron 运行时** —— 直接调用原生能力获取 CPU 型号字符串并做正则匹配。  
2. **在浏览器运行时** —— 用 Web API 先判断是否 x86_64，再借助可信后端或扩展把型号传回前端。

下面给出两段可直接落地的 TypeScript 代码片段，均只依赖稳定的库，无管理员权限要求。

---

### ✅ **Node.js / Electron 场景（最可靠）**

依赖：`systeminformation`（跨平台、无原生编译、MIT 许可）

```bash
npm i systeminformation
```

```ts
// detect-ultra.ts
import si from 'systeminformation';

/**
 * 返回 true 当且仅当 CPU 品牌字符串里包含 "Core Ultra"
 * 性能：首次调用 ~5 ms，后续缓存
 */
export async function isIntelCoreUltra(): Promise<boolean> {
  try {
    const { manufacturer, brand } = await si.cpu();
    const isIntel = /^GenuineIntel$/i.test(manufacturer);
    const isUltra = /Core\s+Ultra\s+\d+/i.test(brand);   // 例： "Intel(R) Core(TM) Ultra 7 155H"
    return isIntel && isUltra;
  } catch {
    return false; // 降级：识别失败视为非 Ultra
  }
}

/* ========== 用法 ========== */
// (async () => {
//   console.log(await isIntelCoreUltra()); // true / false
// })();
```

---

### ⚠️ **纯浏览器场景（仅做软提示）**

浏览器出于隐私考虑 **不会暴露精确型号**，只能判断架构。若必须检测，采用“扩展 + 后端”模式：

1. 浏览器端：  
```ts
// ultra-guard.ts
export async function checkUltraInBrowser(): Promise<boolean> {
  // 1. 先过滤掉明显不匹配的架构
  const ua = navigator.userAgent;
  if (!/x64|x86_64|Win64|WOW64/i.test(ua)) return false;

  // 2. 调用一个可信的后端接口（由扩展或本地代理提供）
  try {
    const { isUltra } = await fetch('/api/is-ultra').then(r => r.json());
    return Boolean(isUltra);
  } catch {
    return false; // 网络异常时保守返回
  }
}
```

2. 后端（Node/Electron 扩展）复用上一段代码，把结果通过 HTTP 或 `chrome.runtime.sendMessage` 回传即可。

---

### 🎯 要点总结

| 场景        | 做法                              | 是否 100% 精确 |
|-------------|-----------------------------------|----------------|
| Node/Electron | `systeminformation` → 正则匹配品牌 | ✅ 是           |
| 浏览器       | 架构过滤 + 扩展/后端辅助          | ⚠️ 依赖扩展    |

在 **硬件识别** 这一环，Node/Electron 侧直接跑第一段代码即可；浏览器侧仅做“软提示”，避免误杀。