# SmartSub NVIDIA CUDA Hardware Acceleration Implementation

## **Architecture Overview**

SmartSub implements NVIDIA CUDA hardware acceleration through a sophisticated multi-layered architecture that combines **native Node.js addons**, **runtime CUDA detection**, and **intelligent fallback mechanisms**.

## **Core Implementation Components**

### **1. CUDA Detection & Validation** (`main/helpers/cudaUtils.ts`)

**Platform-Specific Detection**:
- **Windows Only**: CUDA support limited to Windows platforms
- **Dual Command Validation**: Checks both `nvcc` (CUDA Toolkit) and `nvidia-smi` (driver)
- **Version Parsing**: Extracts CUDA version from `nvidia-smi` output using regex
- **Intelligent Version Mapping**: 
  - CUDA ≥12.0 → Uses CUDA 12.4.1 addon
  - CUDA ≥11.8 → Uses CUDA 11.8.0 addon
  - Otherwise → Returns false (no CUDA support)

```typescript
// Key detection logic from cudaUtils.ts:40
export function checkCudaSupport() {
  if (process.platform !== 'win32') return false;
  
  try {
    execSync('nvcc --version', { encoding: 'utf8' });
    const nsmiResult = execSync('nvidia-smi', { encoding: 'utf8' });
    const cudaVersionMatch = nsmiResult.match(/CUDA Version: (\d+\.\d+)/);
    
    if (cudaVersionMatch) {
      const cudaVersion = parseFloat(cudaVersionMatch[1]);
      if (cudaVersion >= 12.0) return '12.4.1';
      else if (cudaVersion >= 11.8) return '11.8.0';
    }
    return false;
  } catch (error) {
    return false;
  }
}
```

### **2. Native Addon Management** (`main/helpers/whisper.ts`)

**Dynamic Addon Loading Strategy**:
- **Runtime Selection**: Chooses appropriate addon based on platform and CUDA availability
- **Fallback Chain**: CUDA → No-CUDA → Generic fallback
- **Platform-Specific Paths**:
  - Windows CUDA: `extraResources/addons/addon.node`
  - Windows No-CUDA: `extraResources/addons/addon-no-cuda.node`
  - Apple Silicon CoreML: `extraResources/addons/addon.coreml.node`

```typescript
// Key addon loading logic from whisper.ts:244
export async function loadWhisperAddon(model) {
  const platform = process.platform;
  const settings = store.get('settings') || { useCuda: false };
  const useCuda = settings.useCuda || false;

  let addonPath;

  if (platform === 'win32' && useCuda) {
    const hasCudaSupport = await checkCudaSupport();
    
    if (hasCudaSupport) {
      addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon.node');
    } else {
      // Fallback to no-cuda version
      addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon-no-cuda.node');
    }
  } else if (isAppleSilicon() && hasEncoderModel(model)) {
    addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon.coreml.node');  
  } else {
    addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon.node');
  }

  // Dynamic loading using process.dlopen
  const module = { exports: { whisper: null } };
  process.dlopen(module, addonPath);
  return module.exports.whisper;
}
```

### **3. Whisper Integration** (`main/helpers/subtitleGenerator.ts`)

**Intelligent GPU Utilization**:
- **Platform Detection**: Different logic for Windows CUDA vs macOS Core ML
- **Runtime Decision**: Determines GPU usage based on hardware availability
- **Performance Optimization**: Optimizes parameters for GPU acceleration

```typescript
// GPU decision logic from subtitleGenerator.ts:90
let shouldUseGpu = false;
if (platform === 'darwin' && arch === 'arm64') {
  shouldUseGpu = true; // Apple Silicon Core ML
} else if (platform === 'win32' && useCuda) {
  shouldUseGpu = !!(await checkCudaSupport()); // Windows CUDA
}
```

## **Build & Distribution Architecture**

### **Multi-Version CUDA Support** (`.github/workflows/release.yml`)

**Automated Build Matrix**:
- **CUDA 11.8.0**: Generic + Optimized versions for older GPUs
- **CUDA 12.2.0**: Generic + Optimized versions for newer GPUs  
- **CUDA 12.4.1**: Generic + Optimized versions for latest GPUs
- **No-CUDA**: Fallback version for systems without CUDA

**Build Strategy**:
```yaml
# Windows CUDA variants
- cuda_version: '11.8.0', cuda_opt: 'generic|optimized'
- cuda_version: '12.2.0', cuda_opt: 'generic|optimized'  
- cuda_version: '12.4.1', cuda_opt: 'generic|optimized'
- cuda_version: 'no-cuda', cuda_opt: 'generic'
```

### **Native Addon Distribution**

**External Dependency Management**:
- **Separate Repository**: Native addons built in `buxuku/whisper.cpp` repository
- **Dynamic Download**: GitHub Actions downloads appropriate addons during build
- **Version-Specific Naming**: `addon-windows-cuda-1241-optimized.node`

**Addon Preparation Process**:
```yaml
# Download specific addon for each build variant
curl -L -o "temp-artifacts/${{ matrix.addon_name }}" \
  "https://github.com/buxuku/whisper.cpp/releases/download/latest/${{ matrix.addon_name }}"

# Copy to application resources  
Copy-Item -Path "temp-artifacts/${{ matrix.addon_name }}" -Destination "extraResources/addons/addon.node"
```

## **Hardware Acceleration Features**

### **Performance Optimizations**

**CUDA-Specific Enhancements**:
- **Memory Management**: Efficient GPU memory allocation for large models
- **Parallel Processing**: Leverages CUDA cores for Whisper inference
- **Model Loading**: Optimized model loading for GPU execution
- **Batch Processing**: Efficient batching for continuous audio processing

**Performance Metrics** (from documentation):
| Hardware | Processing Time (10min video) | Speedup | Memory Usage |
|----------|------------------------------|---------|--------------|
| CPU (8-core) | 15-25 minutes | 1x | Medium |
| NVIDIA GTX 1660 | 5-8 minutes | 3x | High |
| NVIDIA RTX 3060 | 3-5 minutes | 5x | High |
| NVIDIA RTX 4080 | 1-3 minutes | 10x | High |

### **Model Compatibility**

**CUDA Model Requirements**:
- **All Model Sizes**: tiny, base, small, medium, large-v3 supported
- **Quantized Models**: q5_0, q8_0 variants supported
- **Memory Scaling**: Larger models require more VRAM
  - 4GB VRAM: small model recommended
  - 8GB+ VRAM: large models supported

### **User Experience Integration**

**Settings Integration**:
- **User Control**: Toggle CUDA acceleration in settings UI
- **Automatic Detection**: System capability detection with user override
- **Performance Feedback**: Real-time processing speed indicators

**Error Handling & Fallbacks**:
- **Graceful Degradation**: Automatic fallback to CPU processing
- **User Notifications**: Clear error messages for CUDA issues
- **Diagnostic Logging**: Detailed logging for troubleshooting

## **Technical Implementation Details**

### **Cross-Platform Strategy**

**Platform-Specific Implementations**:
- **Windows**: CUDA acceleration via NVIDIA toolkit integration
- **macOS (Apple Silicon)**: Core ML acceleration for M-series chips
- **Linux**: CUDA support (though not emphasized in current builds)

### **Security & Stability**

**Robust Error Handling**:
- **Exception Catching**: All CUDA operations wrapped in try-catch blocks
- **Validation Chains**: Multiple validation steps before GPU usage
- **Resource Cleanup**: Proper cleanup of GPU resources after processing

### **Development Challenges & Solutions**

**Cross-Platform Development**:
- **Challenge**: Developer using Apple Silicon, can't test CUDA directly
- **Solution**: Automated GitHub Actions builds with multiple CUDA versions
- **Testing**: Community feedback and automated build verification

**Version Compatibility**:
- **Challenge**: Multiple CUDA versions with different compatibility requirements
- **Solution**: Version detection with automatic addon selection
- **Maintenance**: Separate optimized and generic builds for maximum compatibility

## **Summary**

SmartSub's CUDA implementation represents a **sophisticated hardware acceleration system** that:

1. **Dynamically detects** CUDA capabilities at runtime
2. **Intelligently selects** appropriate native addons based on system configuration  
3. **Provides seamless fallbacks** when CUDA is unavailable
4. **Delivers significant performance improvements** (3-10x speedup) for supported hardware
5. **Maintains cross-platform compatibility** while maximizing platform-specific optimizations

The implementation successfully bridges the gap between **web technologies** (Electron/Node.js) and **native GPU acceleration** through carefully orchestrated build processes and runtime detection mechanisms.