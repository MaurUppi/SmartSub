# Design - Intel OpenVINO GPU Acceleration Integration

## Design Overview

This design extends SmartSub's existing GPU acceleration architecture to support Intel GPUs via OpenVINO toolkit, providing 2-8x performance improvements for Intel GPU users while maintaining full backward compatibility.

### Design Philosophy
- **Architectural Reuse**: Leverage 100% of existing CUDA patterns and extend rather than replace
- **Compatibility First**: Maintain backward compatibility with all existing functionality
- **Progressive Enhancement**: Add Intel GPU support as additional acceleration option
- **Graceful Degradation**: Comprehensive fallback chains ensure reliability
- **Developer Experience**: Comprehensive mocking system for macOS development

## System Architecture

### High-Level Architecture Diagram

```
┌─────────────────────────────────────── SmartSub Application ────────────────────────────────────────┐
│                                                                                                      │
│  ┌─────────────────────────────────── Hardware Detection Layer ──────────────────────────────────┐  │
│  │                                                                                                │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │  │
│  │  │ NVIDIA GPU  │  │ Intel GPU   │  │ Apple GPU   │  │ CPU         │  │ Mock System │         │  │
│  │  │ (CUDA)      │  │ (OpenVINO)  │  │ (CoreML)    │  │ (Fallback)  │  │ (Dev)       │         │  │
│  │  │             │  │             │  │             │  │             │  │             │         │  │
│  │  │ ✅ Existing │  │ 🆕 New      │  │ ✅ Existing │  │ ✅ Existing │  │ 🆕 New      │         │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘         │  │
│  │                                                                                                │  │
│  └────────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                              │                                                      │
│                                              ▼                                                      │
│  ┌─────────────────────────────────── Runtime Selection Engine ──────────────────────────────────┐  │
│  │                                                                                                │  │
│  │  Priority Chain: NVIDIA CUDA → Intel OpenVINO → Apple CoreML → CPU Fallback                  │  │
│  │                                                                                                │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                         │  │
│  │  │ GPU         │  │ Settings    │  │ User        │  │ Fallback    │                         │  │
│  │  │ Detection   │  │ Preferences │  │ Override    │  │ Logic       │                         │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘                         │  │
│  │                                                                                                │  │
│  └────────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                              │                                                      │
│                                              ▼                                                      │
│  ┌─────────────────────────────────── Addon Loading System ────────────────────────────────────┐  │
│  │                                                                                                │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                         │  │
│  │  │addon-cuda   │  │addon-       │  │addon-coreml │  │addon-cpu    │                         │  │
│  │  │.node        │  │openvino.node│  │.node        │  │.node        │                         │  │
│  │  │             │  │             │  │             │  │             │                         │  │
│  │  │ ✅ Existing │  │ 🆕 New      │  │ ✅ Existing │  │ ✅ Existing │                         │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘                         │  │
│  │                                                                                                │  │
│  └────────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                              │                                                      │
│                                              ▼                                                      │
│  ┌─────────────────────────────────── Processing Engine ────────────────────────────────────────┐  │
│  │                                                                                                │  │
│  │  whisper.cpp with OpenVINO Backend Integration                                                │  │
│  │  ┌─────────────────────────────────────────────────────────────┐                             │  │
│  │  │                     GPU Processing                          │                             │  │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │                             │  │
│  │  │  │ CUDA        │  │ OpenVINO    │  │ CoreML      │         │                             │  │
│  │  │  │ Backend     │  │ Backend     │  │ Backend     │         │                             │  │
│  │  │  └─────────────┘  └─────────────┘  └─────────────┘         │                             │  │
│  │  └─────────────────────────────────────────────────────────────┘                             │  │
│  │                                                                                                │  │
│  └────────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                      │
└──────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### Multi-GPU Detection Architecture

```
┌──────────────────────── Multi-GPU Scenario Handling ─────────────────────────┐
│                                                                               │
│  ┌─────────────────────── Intel Core Ultra + NVIDIA dGPU ────────────────────┐ │
│  │                                                                           │ │
│  │  [Intel Xe Graphics (iGPU)] ←→ [NVIDIA RTX 3060 (dGPU)]                 │ │
│  │           ↓                              ↓                                 │ │
│  │    OpenVINO Backend              CUDA Backend                            │ │
│  │    Priority: 2                   Priority: 1                            │ │
│  │                                                                           │ │
│  └───────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  ┌─────────────────────── Intel Core Ultra + Intel Arc ──────────────────────┐ │
│  │                                                                           │ │
│  │  [Intel Xe Graphics (iGPU)] ←→ [Intel Arc A750 (dGPU)]                  │ │
│  │           ↓                              ↓                                 │ │
│  │    OpenVINO Backend              OpenVINO Backend                        │ │
│  │    Priority: 2                   Priority: 1                            │ │
│  │                                                                           │ │
│  └───────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  Auto-Detection Logic:                                                       │
│  1. Enumerate all GPU devices with detailed identification                   │
│  2. Apply priority ranking (discrete > integrated)                          │
│  3. Validate OpenVINO/CUDA compatibility                                     │
│  4. Present user dropdown with all detected options                         │
│  5. Allow manual override of automatic selection                            │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

## Component Design

### 1. Hardware Detection System (`hardwareUtils.ts`)

**Purpose**: Comprehensive multi-GPU detection and enumeration system extending existing CUDA patterns.

#### Core Interface Design

```typescript
// Enhanced GPU Detection Interface
interface GPUDevice {
  id: string;                    // Unique identifier
  name: string;                  // Display name
  type: 'discrete' | 'integrated'; // GPU type
  vendor: 'nvidia' | 'intel' | 'apple'; // Vendor
  deviceId: string;              // Hardware device ID
  priority: number;              // Selection priority (1=highest)
  driverVersion: string;         // Driver version
  memory: number | 'shared';     // VRAM in MB or 'shared'
  capabilities: {
    openvinoCompatible: boolean;
    cudaCompatible: boolean;
    coremlCompatible: boolean;
  };
  powerEfficiency: 'excellent' | 'good' | 'moderate';
  performance: 'high' | 'medium' | 'low';
}

interface GPUCapabilities {
  nvidia: boolean;               // CUDA support available
  intel: GPUDevice[];           // Array of Intel GPUs (sorted by priority)
  intelAll: GPUDevice[];        // All Intel GPUs for UI dropdown
  apple: boolean;               // CoreML support available
  cpu: boolean;                 // Always true
  openvinoVersion: string | false; // OpenVINO version or false
  capabilities: {
    multiGPU: boolean;          // Multiple GPUs detected
    hybridSystem: boolean;      // Mixed vendor GPUs
  };
}
```

#### Multi-GPU Enumeration Implementation

```typescript
export function enumerateIntelGPUs(): GPUDevice[] {
  const intelGPUs: GPUDevice[] = [];
  
  try {
    if (process.platform === 'win32') {
      // Windows: WMI enumeration for comprehensive GPU detection  
      const wmiQuery = 'wmic path win32_VideoController get Name,DeviceID,AdapterRAM,DriverVersion /format:csv';
      const result = execSync(wmiQuery, { encoding: 'utf8' });
      
      const gpuEntries = parseWMIOutput(result);
      gpuEntries.forEach((entry, index) => {
        if (isIntelGPU(entry.name)) {
          intelGPUs.push({
            id: `intel_gpu_${index}`,
            name: entry.name,
            type: classifyIntelGPUType(entry.name),
            vendor: 'intel',
            deviceId: `GPU${index}`,
            priority: getIntelGPUPriority(entry.name),
            driverVersion: entry.driverVersion || 'unknown',
            memory: parseMemorySize(entry.adapterRAM),
            capabilities: {
              openvinoCompatible: validateOpenVINOCompatibility(entry.name),
              cudaCompatible: false,
              coremlCompatible: false
            },
            powerEfficiency: getIntelGPUPowerEfficiency(entry.name),
            performance: getIntelGPUPerformance(entry.name)
          });
        }
      });
    } 
    
    else if (process.platform === 'linux') {
      // Linux: lspci + sysfs enumeration
      const lspciResult = execSync('lspci -nn | grep -i "VGA.*Intel\\|3D.*Intel"', { encoding: 'utf8' });
      const gpuLines = lspciResult.split('\n').filter(line => line.trim());
      
      gpuLines.forEach((line, index) => {
        const gpuInfo = parseLinuxGPUInfo(line);
        intelGPUs.push({
          id: `intel_gpu_${index}`,
          name: gpuInfo.name,
          type: classifyIntelGPUType(gpuInfo.name),
          vendor: 'intel',
          deviceId: `GPU${index}`,
          priority: getIntelGPUPriority(gpuInfo.name),
          driverVersion: getLinuxIntelDriverVersion(index),
          memory: getLinuxGPUMemory(index),
          capabilities: {
            openvinoCompatible: validateLinuxOpenVINOCompatibility(gpuInfo.name),
            cudaCompatible: false,
            coremlCompatible: false
          },
          powerEfficiency: getIntelGPUPowerEfficiency(gpuInfo.name),
          performance: getIntelGPUPerformance(gpuInfo.name)
        });
      });
    }
    
    // Sort by priority (discrete first, then by performance)
    return intelGPUs.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      if (a.performance !== b.performance) {
        const perfOrder = { 'high': 1, 'medium': 2, 'low': 3 };
        return perfOrder[a.performance] - perfOrder[b.performance];
      }
      return 0;
    });
    
  } catch (error) {
    logMessage(`Intel GPU enumeration failed: ${error.message}`, 'warning');
    return [];
  }
}
```

#### OpenVINO Validation System

```typescript
export function checkOpenVINOSupport(): OpenVINOInfo | false {
  try {
    // Primary: Python bindings detection
    const pythonCheck = execSync('python -c "import openvino; print(openvino.__version__)"', 
      { encoding: 'utf8', timeout: 5000 });
    
    const versionMatch = pythonCheck.match(/(\d+\.\d+\.\d+)/);
    if (versionMatch) {
      const version = versionMatch[1];
      
      return {
        version,
        compatible: validateOpenVINOVersion(version),
        installPath: getOpenVINOInstallPath(),
        gpuSupported: validateGPUPlugin(),
        runtimeLibraries: validateRuntimeLibraries(),
        pythonBinding: true,
        installationMethod: 'pip'
      };
    }
    
    // Fallback: Environment variable detection
    const envPath = process.env.INTEL_OPENVINO_DIR;
    if (envPath && fs.existsSync(envPath)) {
      return {
        version: 'env-detected',
        compatible: true,
        installPath: envPath,
        gpuSupported: validateEnvironmentGPUPlugin(envPath),
        runtimeLibraries: validateEnvironmentLibraries(envPath),
        pythonBinding: false,
        installationMethod: 'manual'
      };
    }
    
    return false;
    
  } catch (error) {
    logMessage(`OpenVINO detection failed: ${error.message}`, 'debug');
    return false;
  }
}

// Version Compatibility Matrix
function validateOpenVINOVersion(version: string): boolean {
  const compatibilityMatrix = {
    '2024.6.0': { compatible: true, stability: 'recommended' },  // whisper.cpp recommended
    '2024.5.0': { compatible: true, stability: 'supported' },
    '2024.4.0': { compatible: true, stability: 'supported' },
    '2025.0.0': { compatible: true, stability: 'beta' },
    '2025.1.0': { compatible: true, stability: 'beta' },
    '2025.2.0': { compatible: true, stability: 'latest' }        // Latest available
  };
  
  return compatibilityMatrix[version]?.compatible || false;
}
```

### 2. Runtime Selection Engine (`whisper.ts` Extension)

**Purpose**: Enhanced addon loading system with intelligent GPU selection and user override capabilities.

#### Addon Loading Logic Design

```typescript
export async function loadWhisperAddon(model: string): Promise<WhisperFunction> {
  const settings = store.get('settings') || {};
  const { useCuda, useOpenVINO, selectedGPUId, gpuPreference } = settings;
  
  // Get comprehensive GPU capabilities
  const gpuCapabilities = detectAvailableGPUs();
  let selectedAddon: AddonInfo | null = null;
  
  // 1. Handle explicit GPU selection (user override)
  if (selectedGPUId && selectedGPUId !== 'auto') {
    selectedAddon = resolveSpecificGPU(selectedGPUId, gpuCapabilities);
    if (selectedAddon) {
      logMessage(`Using user-selected GPU: ${selectedAddon.displayName}`, 'info');
    }
  }
  
  // 2. Fallback to priority-based selection
  if (!selectedAddon) {
    const priority = gpuPreference || ['nvidia', 'intel', 'apple', 'cpu'];
    selectedAddon = selectOptimalGPU(priority, gpuCapabilities, model);
  }
  
  // 3. Load and validate addon
  return await loadAndValidateAddon(selectedAddon);
}

// GPU Selection Strategy
function selectOptimalGPU(
  priority: string[], 
  capabilities: GPUCapabilities, 
  model: string
): AddonInfo {
  
  for (const gpuType of priority) {
    switch (gpuType) {
      case 'nvidia':
        if (capabilities.nvidia && validateModelSupport('cuda', model)) {
          return {
            type: 'cuda',
            path: path.join(getExtraResourcesPath(), 'addons', 'addon-cuda.node'),
            displayName: 'NVIDIA CUDA GPU',
            deviceConfig: null
          };
        }
        break;
        
      case 'intel':
        if (capabilities.intel.length > 0) {
          const bestIntelGPU = selectBestIntelGPU(capabilities.intel, model);
          if (bestIntelGPU && validateModelSupport('openvino', model)) {
            return {
              type: 'openvino',
              path: path.join(getExtraResourcesPath(), 'addons', 'addon-openvino.node'),
              displayName: `Intel ${bestIntelGPU.name}`,
              deviceConfig: {
                deviceId: bestIntelGPU.deviceId,
                memory: bestIntelGPU.memory,
                type: bestIntelGPU.type
              }
            };
          }
        }
        break;
        
      case 'apple':
        if (capabilities.apple && validateModelSupport('coreml', model)) {
          return {
            type: 'coreml',
            path: path.join(getExtraResourcesPath(), 'addons', 'addon-coreml.node'),
            displayName: 'Apple CoreML',
            deviceConfig: null
          };
        }
        break;
    }
  }
  
  // CPU fallback (always available)
  return {
    type: 'cpu',
    path: path.join(getExtraResourcesPath(), 'addons', 'addon-cpu.node'),
    displayName: 'CPU Processing',
    deviceConfig: null
  };
}
```

### 3. Processing Integration (`subtitleGenerator.ts`)

**Purpose**: Integrate Intel GPU processing into existing subtitle generation workflow with enhanced error handling.

#### Enhanced Processing Configuration

```typescript
export async function generateSubtitleWithBuiltinWhisper(
  event: IpcMainEvent, 
  file: IFiles, 
  formData: FormData
): Promise<string> {
  
  event.sender.send('taskFileChange', { ...file, extractSubtitle: 'loading' });
  
  try {
    const { tempAudioFile, srtFile } = file;
    const { model, sourceLanguage, prompt, maxContext } = formData;
    const whisperModel = model?.toLowerCase();
    
    // Load appropriate addon
    const whisper = await loadWhisperAddon(whisperModel);
    const whisperAsync = promisify(whisper);
    
    // Get enhanced GPU configuration
    const gpuConfig = await determineGPUConfiguration(whisperModel);
    
    // Prepare whisper parameters with GPU settings
    const whisperParams = {
      language: sourceLanguage || 'auto',
      model: `${getPath('modelsPath')}/ggml-${whisperModel}.bin`,
      fname_inp: tempAudioFile,
      
      // Enhanced GPU configuration
      use_gpu: gpuConfig.useGPU,
      gpu_device: gpuConfig.deviceType,
      gpu_device_id: gpuConfig.deviceId,
      
      // OpenVINO specific parameters
      ...(gpuConfig.deviceType === 'intel' && {
        openvino_device: gpuConfig.openvinoDevice,
        openvino_cache_dir: gpuConfig.cacheDir
      }),
      
      // Standard parameters + VAD settings
      flash_attn: false,
      no_prints: false,
      comma_in_time: false,
      translate: false,
      no_timestamps: false,
      audio_ctx: 0,
      max_len: 0,
      print_progress: true,
      prompt,
      max_context: +(maxContext ?? -1),
      ...getVADSettings(),
      
      // Progress callback
      progress_callback: (progress: number) => {
        event.sender.send('taskProgressChange', file, 'extractSubtitle', progress);
      }
    };
    
    // Execute processing with performance monitoring
    const startTime = Date.now();
    const result = await whisperAsync(whisperParams);
    const processingTime = Date.now() - startTime;
    
    // Enhanced performance reporting
    logMessage(
      `Processing completed in ${processingTime}ms using ${gpuConfig.displayName}`,
      'info'
    );
    
    // Process and save results
    const formattedSrt = formatSrtContent(result?.transcription || []);
    await fs.promises.writeFile(srtFile, formattedSrt);
    
    event.sender.send('taskFileChange', { ...file, extractSubtitle: 'done' });
    logMessage('Subtitle generation completed successfully', 'info');
    
    return srtFile;
    
  } catch (error) {
    return await handleProcessingError(error, event, file, formData);
  }
}
```

### 4. Settings UI Design

**Purpose**: Enhanced settings interface with comprehensive GPU selection and configuration options.

#### GPU Selection Interface

```typescript
interface GPUOption {
  id: string;
  displayName: string;
  type: 'nvidia' | 'intel-discrete' | 'intel-integrated' | 'apple' | 'cpu';
  status: 'available' | 'unavailable' | 'requires-setup';
  performance: 'high' | 'medium' | 'low';
  description: string;
  driverVersion?: string;
  memory?: number | 'shared';
  powerEfficiency: 'excellent' | 'good' | 'moderate';
  estimatedSpeed?: string; // e.g., "3-4x faster than CPU"
}

// Main GPU Selection Component
const GPUSelectionComponent = ({ availableGPUs, selectedGPUId, onGPUChange }: GPUSelectionProps) => {
  return (
    <div className="gpu-selection">
      <label htmlFor="gpu-select">GPU Acceleration:</label>
      
      <select 
        id="gpu-select" 
        value={selectedGPUId} 
        onChange={(e) => onGPUChange(e.target.value)}
        className="gpu-dropdown"
      >
        <option value="auto">Auto-detect (Recommended)</option>
        
        {availableGPUs.map(gpu => (
          <option 
            key={gpu.id} 
            value={gpu.id}
            disabled={gpu.status !== 'available'}
          >
            {gpu.displayName} 
            {gpu.status === 'available' && ` - ${gpu.estimatedSpeed}`}
            {gpu.status === 'requires-setup' && ' - Setup Required'}
            {gpu.status === 'unavailable' && ' - Unavailable'}
          </option>
        ))}
      </select>
      
      <GPUInfoPanel selectedGPU={getSelectedGPU(selectedGPUId, availableGPUs)} />
      <GPUAdvancedSettings selectedGPU={getSelectedGPU(selectedGPUId, availableGPUs)} />
    </div>
  );
};
```

## Build System Design

### Enhanced CI/CD Pipeline Architecture

```yaml
# .github/workflows/release.yml - OpenVINO Build Matrix Extension

strategy:
  matrix:
    include:
      # Existing builds...
      
      # Windows OpenVINO Builds
      - os: windows-2022
        arch: x64
        os_build_arg: win
        addon_name: addon-windows-openvino.node
        openvino_version: '2024.6.0'
        python_version: '3.10'
        artifact_suffix: windows-x64-openvino
        build_flags: -DWHISPER_OPENVINO=ON
        
      # Linux OpenVINO Builds
      - os: ubuntu-20.04
        arch: x64
        os_build_arg: linux
        addon_name: addon-linux-openvino.node
        openvino_version: '2024.6.0'
        python_version: '3.10'
        artifact_suffix: linux-x64-openvino
        build_flags: -DWHISPER_OPENVINO=ON

steps:
  - name: Setup Python for OpenVINO
    if: matrix.openvino_version
    uses: actions/setup-python@v4
    with:
      python-version: ${{ matrix.python_version }}
      
  - name: Install OpenVINO Toolkit
    if: matrix.openvino_version
    run: |
      pip install openvino==${{ matrix.openvino_version }}
      pip install openvino-dev==${{ matrix.openvino_version }}
      python -c "import openvino; print(f'OpenVINO {openvino.__version__} installed')"
      
  - name: Build whisper.cpp with OpenVINO
    if: matrix.openvino_version
    working-directory: ./whisper.cpp-fork
    run: |
      cmake -B build \
        ${{ matrix.build_flags }} \
        -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_INTERPROCEDURAL_OPTIMIZATION=ON
      cmake --build build -j --config Release
      
  - name: Validate OpenVINO Integration
    if: matrix.openvino_version
    run: |
      python -c "
      import openvino.runtime as ov
      core = ov.Core()
      devices = core.available_devices
      print(f'Available devices: {devices}')
      gpu_devices = [d for d in devices if 'GPU' in d]
      print(f'GPU devices: {gpu_devices if gpu_devices else \"None (expected in CI)\"}')"
```

## Error Handling & Recovery Design

### Comprehensive Error Classification System

```typescript
export class GPUErrorHandler {
  
  private static readonly ERROR_PATTERNS = {
    DRIVER_OUTDATED: {
      patterns: [/driver.*outdated/i, /version.*incompatible/i],
      severity: 'high',
      category: 'driver',
      autoRecovery: false
    },
    
    OPENVINO_MISSING: {
      patterns: [/openvino.*not.*found/i, /import.*openvino.*failed/i],
      severity: 'high',
      category: 'toolkit',
      autoRecovery: true
    },
    
    GPU_MEMORY_INSUFFICIENT: {
      patterns: [/out.*of.*memory/i, /allocation.*failed/i, /insufficient.*memory/i],
      severity: 'medium',
      category: 'resource',
      autoRecovery: true
    }
  };
  
  static async handleError(error: Error, context: ProcessingContext): Promise<ErrorResolution> {
    const classification = this.classifyError(error);
    const resolution = await this.generateResolution(classification, context);
    
    // Attempt automatic recovery if possible
    if (classification.autoRecovery && resolution.recoveryStrategy) {
      const recoveryResult = await this.attemptRecovery(resolution.recoveryStrategy, context);
      
      if (recoveryResult.success) {
        logMessage(`Automatic recovery successful: ${recoveryResult.method}`, 'info');
        return { ...resolution, recovered: true, recoveryMethod: recoveryResult.method };
      }
    }
    
    // Generate user-facing error message
    const userMessage = this.generateUserMessage(classification, resolution, context);
    
    return {
      ...resolution,
      recovered: false,
      userMessage,
      supportInfo: this.generateSupportInfo(classification, context)
    };
  }
}
```

## Development Environment Design

### macOS Development Mock System

```typescript
export class DevelopmentMockSystem {
  
  private static mockEnabled = false;
  private static mockGPUs: GPUDevice[] = [];
  
  static initialize() {
    if (process.env.NODE_ENV === 'development' && process.platform === 'darwin') {
      this.mockEnabled = true;
      this.setupMockGPUs();
      this.setupMockOpenVINO();
      this.setupMockAddons();
      
      logMessage('Development mock system initialized', 'debug');
    }
  }
  
  private static setupMockGPUs() {
    this.mockGPUs = [
      {
        id: 'mock_intel_arc_a770',
        name: 'Intel Arc A770 (Mock)',
        type: 'discrete',
        vendor: 'intel',
        deviceId: 'GPU0',
        priority: 1,
        driverVersion: '31.0.101.4146',
        memory: 8192,
        capabilities: {
          openvinoCompatible: true,
          cudaCompatible: false,
          coremlCompatible: false
        },
        powerEfficiency: 'good',
        performance: 'high'
      },
      {
        id: 'mock_intel_xe_core_ultra',
        name: 'Intel Xe Graphics - Core Ultra (Mock)',
        type: 'integrated',
        vendor: 'intel',
        deviceId: 'GPU1',
        priority: 2,
        driverVersion: '31.0.101.4146',
        memory: 'shared',
        capabilities: {
          openvinoCompatible: true,
          cudaCompatible: false,
          coremlCompatible: false
        },
        powerEfficiency: 'excellent',
        performance: 'medium'
      }
    ];
    
    // Inject into global scope for detection functions
    global.__MOCK_INTEL_GPUS = this.mockGPUs.filter(gpu => gpu.vendor === 'intel');
  }
  
  // Mock Processing Time Calculation
  private static calculateMockProcessingTime(params: any): number {
    const baseTime = 2000; // 2 seconds base
    
    if (params.gpu_device === 'intel') {
      const gpu = this.mockGPUs.find(g => g.vendor === 'intel' && g.type === 'discrete');
      return gpu ? baseTime * 0.3 : baseTime * 0.5; // Discrete vs integrated
    }
    
    return baseTime; // CPU performance
  }
  
  static createTestScenarios(): TestScenario[] {
    return [
      {
        name: 'Intel Arc A770 + OpenVINO',
        description: 'High-performance discrete Intel GPU with OpenVINO',
        setup: () => {
          global.__MOCK_SELECTED_GPU = this.mockGPUs[0];
          global.__MOCK_OPENVINO_ENABLED = true;
        }
      },
      {
        name: 'Intel Core Ultra iGPU',
        description: 'Integrated Intel GPU with shared memory',
        setup: () => {
          global.__MOCK_SELECTED_GPU = this.mockGPUs[1];
          global.__MOCK_OPENVINO_ENABLED = true;
        }
      },
      {
        name: 'Hybrid System (Intel + NVIDIA)',
        description: 'Multi-GPU system with both Intel and NVIDIA options',
        setup: () => {
          global.__MOCK_MULTI_GPU = true;
          global.__MOCK_NVIDIA_AVAILABLE = true;
        }
      }
    ];
  }
}
```

## Performance Monitoring & Testing Strategy

### Comprehensive Test Suite Design

```typescript
describe('Intel OpenVINO Integration', () => {
  
  beforeAll(async () => {
    DevelopmentMockSystem.initialize();
  });
  
  describe('Hardware Detection', () => {
    test('should detect Intel GPUs correctly', async () => {
      const mockGPUs = DevelopmentMockSystem.getMockGPUs();
      const detected = enumerateIntelGPUs();
      
      expect(detected).toHaveLength(mockGPUs.filter(g => g.vendor === 'intel').length);
      expect(detected[0].type).toBe('discrete');
      expect(detected[1].type).toBe('integrated');
    });
    
    test('should handle multi-GPU scenarios', async () => {
      global.__MOCK_MULTI_GPU = true;
      
      const capabilities = detectAvailableGPUs();
      
      expect(capabilities.capabilities.multiGPU).toBe(true);
      expect(capabilities.capabilities.hybridSystem).toBe(true);
      expect(capabilities.intel.length).toBeGreaterThan(0);
    });
    
    test('should validate OpenVINO compatibility', async () => {
      const openvinoInfo = checkOpenVINOSupport();
      
      expect(openvinoInfo).toBeTruthy();
      expect(openvinoInfo.version).toBe('2024.6.0');
      expect(openvinoInfo.compatible).toBe(true);
    });
  });
  
  describe('Processing Integration', () => {
    test('should process subtitles with Intel GPU', async () => {
      const mockEvent = createMockIpcEvent();
      const mockFile = createMockFileInfo();
      const mockFormData = { model: 'base', sourceLanguage: 'auto' };
      
      const result = await generateSubtitleWithBuiltinWhisper(
        mockEvent,
        mockFile,
        mockFormData
      );
      
      expect(result).toBeDefined();
      expect(fs.existsSync(result)).toBe(true);
    });
    
    test('should handle processing errors gracefully', async () => {
      // Simulate processing error
      global.__MOCK_PROCESSING_ERROR = 'GPU memory allocation failed';
      
      const mockEvent = createMockIpcEvent();
      const mockFile = createMockFileInfo();
      const mockFormData = { model: 'large', sourceLanguage: 'auto' };
      
      // Should not throw, should fallback to CPU
      const result = await generateSubtitleWithBuiltinWhisper(
        mockEvent,
        mockFile,
        mockFormData
      );
      
      expect(result).toBeDefined();
    });
  });
});
```

## Success Metrics & Validation Criteria

### Primary Success Criteria (Must Meet All)

```typescript
static readonly PRIMARY_CRITERIA = {
  FUNCTIONAL_SUCCESS: {
    intel_gpu_detection: { target: 98, unit: '% accuracy on compatible hardware' },
    openvino_addon_loading: { target: 100, unit: '% success when toolkit installed' },
    graceful_fallback: { target: 100, unit: '% fallback success on GPU failure' },
    settings_persistence: { target: 100, unit: '% preference retention across restarts' }
  },
  
  COMPATIBILITY_SUCCESS: {
    intel_core_ultra_stable: { target: 100, unit: '% success rate subtitle generation' },
    intel_arc_support: { target: 100, unit: '% A310-A770 model support' },
    multi_gpu_enumeration: { target: 95, unit: '% accuracy in hybrid scenarios' },
    hybrid_system_compatibility: { target: 100, unit: '% Intel+NVIDIA scenario handling' }
  },
  
  RELIABILITY_SUCCESS: {
    consecutive_runs: { target: 100, unit: 'runs without crash' },
    memory_leak_prevention: { target: 1, unit: '% memory growth over 10 runs (max)' },
    error_recovery: { target: 100, unit: '% error scenarios with graceful recovery' }
  }
};
```

### Secondary Success Criteria (Performance Goals)

```typescript
static readonly SECONDARY_CRITERIA = {
  PERFORMANCE_SUCCESS: {
    intel_arc_speedup: { target: 3, unit: 'x faster than CPU (minimum)' },
    intel_xe_speedup: { target: 2, unit: 'x faster than CPU (minimum)' },
    system_stability: { target: 0, unit: '% performance regression for existing users' },
    memory_efficiency: { target: 'reasonable', unit: 'resource usage impact' }
  },
  
  USER_EXPERIENCE: {
    initialization_time: { target: 30, unit: 'seconds first-run OpenVINO setup (max)' },
    error_message_clarity: { target: 90, unit: '% user understanding of error messages' },
    settings_usability: { target: 95, unit: '% user success with GPU selection' }
  }
};
```

## Implementation Timeline

### Phase-Based Development Approach

#### Phase 1: Foundation (Week 1-2) - LOW RISK
```yaml
scope: Core detection & validation system
deliverables:
  - hardwareUtils.ts (Intel GPU + OpenVINO detection with multi-GPU support)
  - Unit tests for detection logic with mock system
  - Documentation updates
  - Development environment setup with macOS mocking
effort: 20-28 hours
risk: Low
validation:
  - Multi-GPU scenario testing
  - Cross-platform detection validation
  - Mock system verification
```

#### Phase 2: Runtime Integration (Week 3-4) - LOW-MEDIUM RISK  
```yaml
scope: Addon loading & GPU utilization logic
deliverables:
  - Enhanced whisper.ts addon selection with user override
  - Modified subtitleGenerator.ts GPU logic with fallback recovery
  - Integration tests with performance monitoring
  - Settings UI for GPU selection dropdown
effort: 28-36 hours
risk: Low-Medium
validation:
  - End-to-end subtitle generation testing
  - GPU fallback scenario validation
  - Performance benchmarking baseline
```

#### Phase 3: Build System (Week 5-6) - MEDIUM-HIGH RISK
```yaml
scope: Build matrix & distribution
deliverables:
  - Enhanced release.yml workflow with OpenVINO variants
  - OpenVINO addon builds for Windows/Linux
  - Automated testing with GPU simulation
  - Distribution strategy with artifact optimization
effort: 36-48 hours
risk: Medium-High
validation:
  - Multi-platform build verification
  - Addon loading smoke tests
  - Distribution package integrity
```

#### Phase 4: Optimization & Release (Week 7-8) - LOW RISK
```yaml
scope: Performance tuning & production readiness
deliverables:
  - Performance optimizations and memory management
  - Comprehensive user documentation with troubleshooting
  - Production deployment with monitoring
  - Community beta testing coordination
effort: 20-28 hours
risk: Low
validation:
  - Performance regression testing
  - User acceptance testing
  - Production stability monitoring
```

## Risk Assessment & Mitigation

### Technical Risk Matrix

| Risk | Probability | Impact | Mitigation Strategy |
|------|-------------|--------|-------------------|
| Intel GPU driver compatibility | Medium | High | Version detection + graceful fallback + user guidance |
| OpenVINO toolkit availability | Low | High | Runtime detection + installation guidance + CPU fallback |
| Build matrix complexity | High | Medium | Incremental rollout + automated testing + parallel builds |
| Multi-GPU detection failures | Medium | High | Comprehensive enumeration + manual override + fallback chains |

### Development Strategy: Git Worktree Approach

```bash
# Setup isolated development environment
git worktree add ../smartsub-openvino-dev feature/openvino-integration
cd ../smartsub-openvino-dev

# Enhanced development workflow:
# 1. Implement OpenVINO features in worktree with mock system
# 2. Test thoroughly in isolation with comprehensive mocking
# 3. Run automated test suite with GPU simulation
# 4. Merge back to main when stable and validated
```

## Conclusion

This design provides a comprehensive, production-ready approach to integrating Intel OpenVINO GPU acceleration into SmartSub. The architecture leverages existing patterns, ensures backward compatibility, and provides robust error handling and recovery mechanisms.

**Key Design Strengths:**
- **Architectural Reuse**: 100% leverage of existing CUDA patterns
- **Multi-GPU Support**: Comprehensive detection and user control
- **Developer Experience**: Full macOS development capability with mocking
- **Production Ready**: Comprehensive error handling and monitoring
- **Risk Managed**: Clear mitigation strategies and contingency plans

**Next Steps**: User approval to proceed to task breakdown and implementation phases.