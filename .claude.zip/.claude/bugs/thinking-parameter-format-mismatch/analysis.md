# Bug Analysis: Thinking Parameter Format Mismatch

**Bug ID**: thinking-parameter-format-mismatch  
**Analysis Date**: 2025-07-30  
**Status**: Analysis Complete  

---

## Root Cause Analysis

### Primary Issue Location
**File**: `main/helpers/parameterProcessor.ts`  
**Lines**: 203-209  
**Method**: `processBodyParameters()`

### Technical Root Cause
The parameter processor uses **hard-coded format conversion** that assumes all providers use Aliyun's boolean format for thinking parameters, but Volcengine requires a different object format.

```typescript
// PROBLEMATIC CODE (Current Implementation)
if (key === 'thinking' && typeof validationResult.convertedValue === 'string') {
  const thinkingValue = validationResult.convertedValue.toLowerCase();
  // ❌ ALWAYS converts to Aliyun format regardless of provider
  const enableThinking = thinkingValue === 'enabled' || thinkingValue === 'auto';
  result.body.enable_thinking = enableThinking;
  result.appliedParameters.push(`body:thinking->enable_thinking`);
}
```

### Provider Format Requirements

| Provider | API Format Required | Current Output | Status |
|----------|-------------------|----------------|---------|
| **Aliyun (Qwen)** | `"enable_thinking": false` | `"enable_thinking": false` | ✅ Working |
| **Volcengine (Doubao)** | `"thinking": { "type": "disabled" }` | `"enable_thinking": false` | ❌ Broken |

### Code Flow Analysis

```mermaid
graph TD
    A[User sets thinking: disabled] --> B[Custom Parameters UI]
    B --> C[Parameter Processor]
    C --> D{Provider Detection}
    D --> E[❌ Always converts to enable_thinking: false]
    E --> F[OpenAI Service]
    F --> G[Volcengine API]
    G --> H[❌ Parameter ignored - wrong format]
```

**Problem**: No provider-specific logic exists in step D.

### Evidence from Debug Log

```json
// From .claude/debug/handleTask.log
{
  "customParameters": {
    "bodyParameters": {
      "thinking": "disabled"  // ✅ Correct input
    }
  }
}

// But API receives:
{
  "enable_thinking": false  // ❌ Wrong format for Volcengine
}

// Should receive for Volcengine:
{
  "thinking": { "type": "disabled" }  // ✅ Correct format
}
```

## Detailed Investigation

### Provider Detection Logic Gaps

**Current State**: No provider-aware parameter formatting  
**Required**: Detect provider type and apply appropriate format

```typescript
// MISSING: Provider detection method
private static isVolcengineProvider(provider: ExtendedProvider): boolean {
  return provider.type === 'doubao' || 
         provider.apiUrl?.includes('volces.com') ||
         provider.apiUrl?.includes('volcengine');
}
```

### API Documentation Compliance

**Volcengine Requirement** (from `Project/Thinking-mode.md`):
```json
{
  "thinking": {
    "type": "disabled"  // Must be: enabled, disabled, auto
  }
}
```

**Aliyun Requirement**:
```json
{
  "enable_thinking": false  // Boolean: true/false
}
```

### Impact Chain Analysis

1. **Parameter Loading**: ✅ Works correctly
2. **UI Configuration**: ✅ Works correctly  
3. **Parameter Processing**: ❌ **BROKEN** - Wrong format conversion
4. **API Request**: ❌ **BROKEN** - Incorrect parameter sent
5. **AI Response**: ❌ **BROKEN** - Thinking mode not disabled
6. **Translation Output**: ❌ **DEGRADED** - Contains unwanted thinking content

## Solution Design

### Recommended Approach: Provider-Aware Parameter Processing

**Strategy**: Modify the parameter processor to detect provider type and apply format accordingly.

### Implementation Plan

#### Step 1: Add Provider Detection
```typescript
// Add to ParameterProcessor class
private static isVolcengineProvider(provider: ExtendedProvider): boolean {
  return provider.type === 'doubao' || 
         provider.apiUrl?.includes('volces.com') ||
         provider.apiUrl?.includes('volcengine');
}
```

#### Step 2: Modify Parameter Processing Logic
```typescript
// Replace existing logic (lines 203-209)
if (key === 'thinking' && typeof validationResult.convertedValue === 'string') {
  const thinkingValue = validationResult.convertedValue.toLowerCase();
  
  // Provider-specific formatting
  if (this.isVolcengineProvider(provider)) {
    // Volcengine format: { "type": "disabled|enabled|auto" }
    result.body.thinking = { type: thinkingValue };
    result.appliedParameters.push(`body:thinking->object`);
    console.log(`Applied Volcengine thinking format: { type: "${thinkingValue}" }`);
  } else {
    // Aliyun format: boolean enable_thinking
    const enableThinking = thinkingValue === 'enabled' || thinkingValue === 'auto';
    result.body.enable_thinking = enableThinking;
    result.appliedParameters.push(`body:thinking->enable_thinking`);
    console.log(`Applied Aliyun thinking format: enable_thinking: ${enableThinking}`);
  }
}
```

### Validation Strategy

#### Test Cases
1. **TC1**: Volcengine provider with `thinking: "disabled"` → API receives `"thinking": { "type": "disabled" }`
2. **TC2**: Volcengine provider with `thinking: "enabled"` → API receives `"thinking": { "type": "enabled" }`
3. **TC3**: Volcengine provider with `thinking: "auto"` → API receives `"thinking": { "type": "auto" }`
4. **TC4**: Aliyun provider with `thinking: "disabled"` → API receives `"enable_thinking": false`
5. **TC5**: Aliyun provider with `thinking: "enabled"` → API receives `"enable_thinking": true`

#### Regression Testing
- Ensure existing Aliyun providers continue working
- Verify parameter validation still works
- Check error handling remains robust

## Risk Assessment

### Implementation Risks
- **Low Risk**: Minimal code changes in isolated area
- **Backward Compatibility**: ✅ Maintained for Aliyun providers
- **Type Safety**: ✅ No type changes required
- **Performance**: ✅ Negligible impact

### Testing Risks
- **Provider Detection**: Must handle edge cases (custom URLs)
- **Parameter Validation**: Ensure object format passes validation
- **Error Handling**: Graceful fallback if detection fails

## Dependencies

### Code Dependencies
- `main/helpers/parameterProcessor.ts` - Primary modification
- `types/parameterSystem.ts` - Type definitions (may need update)
- `main/service/openai.ts` - Integration point (verify compatibility)

### External Dependencies
- Volcengine API endpoint: `https://ark.cn-beijing.volces.com/api/v3/`
- Aliyun API endpoint: `https://dashscope.aliyuncs.com/compatible-mode/v1/`

---

**Analysis Completed**: 2025-07-30  
**Confidence**: 95% - Root cause definitively identified  
**Ready for Fix Phase**: ✅ Implementation plan complete