# Bug Report: Thinking Parameter Format Mismatch

**Bug ID**: thinking-parameter-format-mismatch  
**Date Created**: 2025-07-30  
**Severity**: High  
**Status**: Reported  

---

## Bug Summary

The "thinking disabled" parameter is not working during translation process for Volcengine/Doubao providers. Users set `thinking: "disabled"` in Custom Parameters, but the AI model continues to show thinking processes in responses, indicating the parameter is not being applied correctly.

## Bug Details

### Expected Behavior
- When user sets `thinking: "disabled"` for Volcengine provider
- The parameter should be formatted as `"thinking": { "type": "disabled" }` in the API request
- The AI model should respond without showing thinking processes
- Translation should work normally without thinking content

### Actual Behavior  
- User sets `thinking: "disabled"` in Custom Parameters UI
- Parameter is converted to `"enable_thinking": false` (Aliyun format) instead of Volcengine object format
- Wrong parameter format sent to Volcengine API
- AI model ignores the parameter and continues showing thinking processes
- Translation includes unwanted thinking content

### Steps to Reproduce
1. Create a Volcengine/Doubao provider (e.g., "DB-Test1")
2. Open Custom Parameters UI for the provider
3. Add body parameter: `thinking` with value `"disabled"`
4. Save and use provider for translation
5. Check debug log (`.claude/debug/handleTask.log`) - shows wrong format
6. Observe AI response contains thinking content despite setting disabled

### Environment
- **Platform**: macOS (Darwin 24.5.0)
- **SmartSub Version**: 2.5.2
- **Provider Type**: Volcengine/Doubao (API URL: `https://ark.cn-beijing.volces.com/api/v3/`)
- **Model**: doubao-seed-1-6-250615
- **Parameter System**: Custom Parameters with dynamic processing

## Impact Assessment

### Severity: High
- **Reason**: Core functionality not working as designed
- **User Impact**: Translation quality degradation due to unwanted thinking content
- **Business Impact**: Users cannot properly control AI model behavior

### Affected Users
- Users using Volcengine/Doubao providers
- Users who want to disable thinking mode for cleaner translations
- Enterprise users requiring consistent translation output

### Affected Features
- Custom Parameters system for Volcengine providers
- Translation process parameter handling
- AI model behavior control
- Provider-specific parameter processing

## Initial Analysis

### Suspected Root Cause
**Format Mismatch**: SmartSub's parameter processor (`main/helpers/parameterProcessor.ts:203-209`) always converts thinking parameter to Aliyun's boolean format (`enable_thinking: false`) instead of recognizing provider-specific requirements.

### Evidence from Investigation
1. **Debug Log Analysis**: Shows `"thinking": "disabled"` in custom parameters but wrong format sent to API
2. **Documentation Review**: Confirmed Volcengine requires `"thinking": { "type": "disabled" }` object format
3. **Code Flow Analysis**: Parameter processor lacks provider-aware formatting logic

### Affected Components
- **Primary**: `main/helpers/parameterProcessor.ts` (lines 203-209)
- **Secondary**: `main/service/openai.ts` (parameter integration)
- **Related**: Custom Parameters UI and validation system

### Technical Details
```typescript
// Current problematic code (parameterProcessor.ts:203-209)
if (key === 'thinking' && typeof validationResult.convertedValue === 'string') {
  const thinkingValue = validationResult.convertedValue.toLowerCase();
  const enableThinking = thinkingValue === 'enabled' || thinkingValue === 'auto';
  result.body.enable_thinking = enableThinking;  // ❌ Always uses Aliyun format
  result.appliedParameters.push(`body:thinking->enable_thinking`);
}
```

### Required Fix
```typescript
// Proposed provider-aware solution
if (key === 'thinking' && typeof validationResult.convertedValue === 'string') {
  const thinkingValue = validationResult.convertedValue.toLowerCase();
  
  if (this.isVolcengineProvider(provider)) {
    // Volcengine format: { "type": "disabled|enabled|auto" }
    result.body.thinking = { type: thinkingValue };
    result.appliedParameters.push(`body:thinking->object`);
  } else {
    // Aliyun format: boolean enable_thinking
    const enableThinking = thinkingValue === 'enabled' || thinkingValue === 'auto';
    result.body.enable_thinking = enableThinking;
    result.appliedParameters.push(`body:thinking->enable_thinking`);
  }
}
```

## References

- **Analysis Document**: `Project/Thinking-Parameter-Analysis-Solution.md`
- **Debug Log**: `.claude/debug/handleTask.log` (lines 24-44)
- **Volcengine API Docs**: https://www.volcengine.com/docs/82379/1449737#0002
- **Aliyun API Docs**: https://help.aliyun.com/zh/model-studio/deep-thinking#4c9ec98bf0sas
- **Provider Documentation**: `Project/Thinking-mode.md`

---

**Report Created By**: Claude Code Analysis  
**Confidence Level**: 95% - Root cause clearly identified  
**Estimated Fix Time**: 30 minutes implementation + 30 minutes testing