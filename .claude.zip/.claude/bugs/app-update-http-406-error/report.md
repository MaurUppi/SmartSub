# App Update HTTP 406 Error Bug Report

## Bug Summary
The app update process fails with "HttpError: 406" when trying to check for updates from GitHub releases. The electron-updater cannot parse the releases feed due to a GitHub API response issue.

## Bug Details

### Expected Behavior
- App should check for updates successfully
- Update process should either find new version 2.6.0 or report "not-available" if current version is up to date
- GitHub releases API should return a valid response for the latest version check

### Actual Behavior
- App throws HttpError: 406 when checking for updates
- Error message: "Cannot parse releases feed: Error: Unable to find latest version on GitHub"
- The updater fails to parse the GitHub releases XML feed despite receiving what appears to be valid XML data

### Steps to Reproduce
1. Launch SmartSub app (current version 2.5.2)
2. Trigger update check
3. App attempts to fetch from https://github.com/MaurUppi/SmartSub/releases/latest
4. Receives HTTP 406 error
5. Update process fails with parsing error

### Environment Details
- Platform: macOS (Darwin)
- App Version: 2.5.2
- GitHub Repo: https://github.com/MaurUppi/SmartSub/releases
- Update Library: electron-updater
- Request URL: https://github.com/MaurUppi/SmartSub/releases/latest

## Impact Assessment

### Severity: High
- **Critical Issue**: Users cannot update the application
- **Widespread Impact**: Affects all users trying to update from version 2.5.2

### Affected Users
- All existing users with version 2.5.2 attempting to update
- New users who might encounter update issues after installation

### Affected Features
- Auto-update functionality
- Manual update checks
- Version synchronization between app and GitHub releases

## Root Cause Analysis

### Primary Issue: GitHub Release Workflow Misconfiguration
1. **Draft Release Problem**: CI workflow creates draft releases that remain unpublished (.github/workflows/release.yml:311)
2. **Tag vs Release Disconnect**: Tags (v2.6.0, v2.6) exist but releases are created as drafts and never published
3. **Workflow Build Success, Release Failure**: Builds complete successfully but releases remain inaccessible to electron-updater

### Technical Details from Logs

#### Normal Log Analysis
- Update status shows "checking" → "not-available" (working state)
- Contains React warnings (controlled/uncontrolled component issue)

#### Failed Log Analysis  
- HTTP 406 error when accessing GitHub releases/latest endpoint
- XML feed shows tags but electron-updater cannot access latest release
- electron-updater expects published GitHub releases with downloadable assets

#### GitHub Workflow Analysis (.github/workflows/release.yml)
- **Issue**: Line 311 sets `draft: true` - releases are created but never published
- **Impact**: Creates builds and artifacts but keeps them as unpublished drafts
- **electron-updater Result**: Cannot access `/releases/latest` → HTTP 406 error

#### Script Analysis (github_publish_script.sh)
- Script creates proper Git tags with version management
- Does not directly integrate with GitHub Actions workflow
- Local script works independently of CI/CD pipeline

### HTTP 406 Root Cause
HTTP 406 (Not Acceptable) occurs because:
- electron-updater requests `/releases/latest` endpoint
- GitHub returns 406 when no **published** releases exist (only drafts)
- Tags exist but releases are unpublished drafts, making them invisible to API

## Fix Solution

### Immediate Fix (Choose One)

#### Option 1: Publish Existing Draft Release
1. Go to https://github.com/MaurUppi/SmartSub/releases
2. Find the draft release for v2.6.0
3. Click "Edit" on the draft release
4. Change from draft to published
5. Ensure all built artifacts are attached

#### Option 2: Fix Workflow and Re-trigger
1. **Edit `.github/workflows/release.yml`**:
   ```yaml
   # Change line 311 from:
   draft: true
   # To:
   draft: false
   ```
2. **Delete and recreate tag**:
   ```bash
   git tag -d v2.6.0
   git push origin --delete v2.6.0
   git tag -a v2.6.0 -m "Release v2.6.0 - 2025-07-31"
   git push origin v2.6.0
   ```

### Long-term Solution
1. **Fix Release Workflow Configuration**:
   - Set `draft: false` in `.github/workflows/release.yml:311`
   - Add proper token configuration if needed
   - Test workflow with minor version bump

2. **Integrate Script with Workflow**:
   - Update `github_publish_script.sh` to work with GitHub Actions
   - Ensure version consistency between local script and CI
   - Add workflow validation steps

3. **App Configuration Verification**:
   - Verify electron-updater configuration matches workflow outputs
   - Test update process in development environment
   - Add update logging for debugging

### Implementation Steps
1. **Immediate**: Publish existing draft or fix workflow + retrigger
2. **Verify Assets**: Ensure all platform binaries are attached to release
3. **Test Update**: Run app update check to verify HTTP 406 is resolved
4. **Monitor**: Check update logs for successful version detection
5. **Document**: Update release process documentation

## Verification Plan
1. Create GitHub release for v2.6.0
2. Test update from version 2.5.2
3. Verify successful update detection
4. Confirm app can download and install update
5. Document successful update process

## Related Files
- App updater configuration
- package.json (publish settings)
- GitHub Actions workflows (if any)
- electron-updater settings

## Notes
- The XML feed shows valid tag information, but GitHub's releases API specifically requires formal releases, not just tags
- Future versions should use proper release creation workflow to prevent this issue
- Consider implementing fallback update mechanism if GitHub releases fail