# Bug Report: Custom Parameters Auto-save Failure & UI Visibility

## Bug Summary
Auto-save functionality in Custom Parameters UI fails with validation error and provides poor visual feedback about save status. Users cannot reliably save parameter configurations and lack clear indication of save state.

## Bug Details

### Issue 1: Auto-save Validation Failure
- **Expected Behavior**: When adding a body parameter manually in Custom Parameters UI, the auto-save should successfully persist the configuration after 2-second debounce
- **Actual Behavior**: Auto-save fails with configuration validation error: "Spread syntax requires ...iterable[Symbol.iterator] to be a function"
- **Steps to Reproduce**:
  1. Create a new customer provider
  2. Open "Custom Parameters" UI 
  3. Input a body parameter manually (e.g., key: "thinking", value: "disable")
  4. Exit the UI
  5. Check console logs - auto-save failure logged

### Issue 2: Poor Save Status Visibility  
- **Expected Behavior**: Clear visual indication of save status (green "saved", red "save failed") in prominent location
- **Actual Behavior**: Only subtle warning icon shown next to refresh button, which is not easily noticeable
- **Steps to Reproduce**:
  1. Open Custom Parameters UI
  2. Make any parameter change
  3. Observe minimal visual feedback about save status

## Environment
- **Platform**: Electron + Next.js (SmartSub application)
- **Development Setup**: 
  - Dev userData: `/Users/ouzy/Library/Application Support/smartsub-dev/` (NO config.json)
  - Prod userData: `/Users/ouzy/Library/Application Support/smartsub/` (HAS config.json)
  - **CRITICAL**: SmartSub-dev appears to be accessing production `smartsub/config.json` instead of dev location
- **Components Affected**: 
  - `renderer/hooks/useParameterConfig.tsx` (auto-save logic)
  - `main/service/parameterValidator.ts` (validation failure)
  - `main/service/configurationManager.ts` (save operation)
  - `renderer/components/CustomParameterEditor.tsx` (UI feedback)

## Impact Assessment
- **Severity**: High - Data loss potential, core functionality broken
- **Affected Users**: All users attempting to save custom parameters
- **Affected Features**: 
  - Custom parameter persistence
  - Auto-save functionality
  - User feedback/UI status indicators

## Technical Analysis from Logs

### Console Log Evidence (debug/Auto-save-failed.log):
```
🔄 [AUTO-SAVE] Triggered for provider: openai_1753771780367 Config: {
  "headerParameters": {},
  "bodyParameters": {
    "thinking": "disable"  
  },
  "configVersion": "1.0.0",
  "lastModified": 1753771913686
}
💾 [AUTO-SAVE] Starting save operation...
📡 [AUTO-SAVE] Calling IPC config-manager:save with: {providerId: 'openai_1753771780367', config: {…}}
📡 [AUTO-SAVE] IPC response: {success: false, error: 'Configuration validation failed: Validation error: Spread syntax requires ...iterable[Symbol.iterator] to be a function'}
❌ [AUTO-SAVE] Save failed - success=false
```

## Root Cause Analysis

### Issue 1A: Configuration File Path Mismatch  
**CRITICAL DISCOVERY**: Development version accessing production config file
- Dev version should use: `smartsub-dev/parameter-configs/configurations.json`
- But appears to access: `smartsub/config.json` (production file)
- This cross-contamination causes configuration conflicts and validation failures

### Issue 1B: Validation Error - Spread Syntax
The error "Spread syntax requires ...iterable[Symbol.iterator] to be a function" occurs in `parameterValidator.ts:80-106`:
```typescript
errors.push(...this.validateStructure(config));           // Line 80
errors.push(...this.validateParameters(headerParameters));  // Line 84-89  
errors.push(...this.validateParameters(bodyParameters));    // Line 93-99
errors.push(...this.validateCrossParameters(config));      // Line 103
errors.push(...this.validateSecurity(config));             // Line 106
```
When any validation method returns `undefined/null` instead of `ValidationError[]`

### Issue 2: UI Feedback
- Current warning icon next to refresh button is too subtle
- Need prominent status indicator in Configuration Summary section
- Should clearly show: saving, saved (green), or failed (red)

## Suspected Root Cause
1. **Config Path Logic**: `background.ts` dev path setup not properly isolated from production
2. **Validation Logic**: `parameterValidator.ts` validation methods returning undefined instead of empty arrays
3. **UI State Management**: Insufficient visual feedback for save status in `CustomParameterEditor.tsx`

## Affected Components
- `main/service/parameterValidator.ts` - Line ~400+ (validation error processing)
- `renderer/hooks/useParameterConfig.tsx` - Auto-save error handling
- `main/service/configurationManager.ts` - Validation integration  
- `renderer/components/CustomParameterEditor.tsx` - Save status UI

## Next Steps
1. **Analyze** validation logic in parameterValidator for spread syntax issues
2. **Fix** validation error handling to prevent undefined/null spreads
3. **Enhance** UI feedback with prominent save status indicators
4. **Test** complete save cycle with various parameter types