# Bug Report: Bailian Provider Custom Parameters Not Working

**Bug ID**: bailian-thinking-parameters  
**Created**: 2025-07-30  
**Severity**: High  
**Status**: Reported  

## Bug Summary

The Bailian-Qwen3 provider's custom parameters (specifically `enable_thinking`) are not being applied during translation processes, unlike the working Doubao provider implementation. Users cannot effectively control thinking mode behavior or receive feedback about parameter application.

## Bug Details

### Expected Behavior
- Custom parameters like `enable_thinking` should be included in API requests to Bailian models
- Parameters should appear in debug logs (similar to Doubao provider)
- Users should receive feedback about thinking mode status during test translations
- Standard models (qwen3-235b-a22b) should support both `enable_thinking: true/false`
- Thinking-only models (qwen3-235b-a22b-thinking-2507) should provide clear error messages when incompatible parameters are used

### Actual Behavior
- **Issue A**: Custom parameters do not appear in translation logs (`.claude/debug/Qwen3-translation.log`)
- **Issue B**: qwen3-235b-a22b-thinking-2507 fails with parameter restrictions but no user feedback
- **Issue C**: qwen3-235b-a22b works with both parameter values but user cannot tell the difference
- **Issue D**: No feedback mechanism in "测试翻译" (Test Translation) to show parameter effectiveness

### Steps to Reproduce
1. Create Bailian-Qwen3 provider with custom parameter `"enable_thinking": false`
2. Use model `qwen3-235b-a22b` or `qwen3-235b-a22b-thinking-2507`
3. Perform translation and check debug logs
4. Click "测试翻译" (Test Translation) button
5. Observe lack of parameter application and user feedback

### Environment Details
- **Provider**: Bailian-Qwen3 (Ali-Bailian)
- **API URL**: https://dashscope.aliyuncs.com/compatible-mode/v1/
- **Models Tested**: 
  - qwen3-235b-a22b (standard model)
  - qwen3-235b-a22b-thinking-2507 (thinking-only model)
- **Working Comparison**: Doubao provider shows parameters correctly in logs
- **Log Files**: `.claude/debug/Qwen3-translation.log`, `.claude/debug/doubao-seed-1-6-250615.log`

## Impact Assessment

### Severity: High
- **Affected Users**: All users using Bailian provider with thinking mode control
- **Affected Features**: 
  - Custom parameter system for Bailian provider
  - Thinking mode optimization (63% performance improvement lost)
  - Test translation feedback mechanism
  - Parameter validation and error handling

### Business Impact
- Users cannot optimize performance by disabling thinking mode
- No feedback mechanism leads to poor user experience
- Parameter system inconsistency between providers
- Debugging difficulty due to missing parameter logs

## Error Evidence

### From Translation Logs
```
2025/7/30 14:50:01 - Translation started with provider: {
  "id": "openai_1753847534717",
  "name": "百炼-Qwen3",
  "type": "openai",
  "apiUrl": "https://dashscope.aliyuncs.com/compatible-mode/v1/",
  "modelName": "qwen3-235b-a22b-thinking-2507"
  // ❌ NO CUSTOM PARAMETERS VISIBLE
}
```

### API Error Response
```
OpenAI translation failed: 400 <400> InternalError.Algo.InvalidParameter: 
The value of the enable_thinking parameter is restricted to True.
```

## Technical Analysis

### Root Cause Hypothesis
Based on analysis, the issue appears to be in the parameter processing pipeline:

1. **Parameter Application**: Custom parameters may not be properly merged into API requests for Bailian provider
2. **Logging Integration**: Custom parameters not included in debug logging output
3. **Response Analysis**: No detection of `reasoning_content` field presence for user feedback
4. **Model Compatibility**: No validation of parameter compatibility with model types

### Expected API Response Indicators
According to test analysis, proper thinking mode detection should show:

**With Thinking Enabled**:
```json
{
  "choices": [{
    "message": {
      "content": "...",
      "reasoning_content": "Let me think about this..." // ← KEY INDICATOR
    }
  }],
  "usage": {
    "reasoning_tokens": 126, // ← SECONDARY INDICATOR
    "completion_tokens": 146
  }
}
```

**With Thinking Disabled**:
```json
{
  "choices": [{
    "message": {
      "content": "..." // No reasoning_content field
    }
  }],
  "usage": {
    "completion_tokens": 72 // No reasoning_tokens field
  }
}
```

## Affected Components
- Parameter processing system (`main/helpers/taskProcessor.ts`, `main/service/openai.ts`)
- Custom parameter configuration (`renderer/hooks/useParameterConfig.tsx`)
- Debug logging system
- Test translation functionality
- Provider configuration UI

## Initial Investigation Needs
1. Verify if custom parameters are being applied to Bailian API requests
2. Check parameter processing differences between Doubao and Bailian providers
3. Implement response analysis for thinking mode detection
4. Add parameter feedback mechanism to test translation feature
5. Implement model compatibility validation

## Next Steps
- **Phase 1**: Analyze parameter processing code for Bailian provider
- **Phase 2**: Implement thinking mode detection and user feedback
- **Phase 3**: Add parameter validation for model compatibility
- **Phase 4**: Test and verify fix with both standard and thinking-only models