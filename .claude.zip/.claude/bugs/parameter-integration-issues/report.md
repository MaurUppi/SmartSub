# Parameter Integration Issues - Bug Report

## Status: 📋 Reported

## Bug Summary
After implementing fixes for the parameter system, two new issues have emerged: persistent DialogContent accessibility warnings and OpenAI translation failures when custom parameters are properly passed to the translation service.

## Bug Details

### Issue 1: Persistent DialogContent Accessibility Warning
- **Expected Behavior**: No React accessibility warnings after adding DialogDescription components
- **Actual Behavior**: Warning still appears: `Warning: Missing 'Description' or 'aria-describedby={undefined}' for {DialogContent}.`
- **Frequency**: Occurs during config load operations
- **Evidence**: Line 6 in `.claude/debug/import-autosave-works.log`
- **User Impact**: Minor - console warnings only, but affects accessibility compliance

### Issue 2: OpenAI Translation Failure with Custom Parameters
- **Expected Behavior**: Translation should work correctly when custom parameters are passed
- **Actual Behavior**: Translation fails with "Cannot convert undefined or null to object"
- **Steps to Reproduce**:
  1. Configure custom parameters (e.g., "thinking": "disabled")
  2. Start translation process
  3. Translation fails on first batch with null/undefined error
- **Evidence**: Lines 53, 62 in `.claude/debug/translation-error.log`
- **User Impact**: High - Translation functionality broken when custom parameters are used

## Impact Assessment

### Severity Assessment
- **Issue 1**: Low (console warnings, accessibility compliance)
- **Issue 2**: Critical (core translation functionality broken)

### Affected Users
- All users using custom parameters with OpenAI translation
- Users with accessibility needs (screen readers) for Issue 1

### Affected Features
- Translation pipeline with custom parameters
- Dialog accessibility compliance

## Environment Details
- **Application**: SmartSub development version
- **Provider**: OpenAI (openai_1753773305649) with DB-Test1 configuration
- **Custom Parameters**: `{"thinking": "disabled"}` (body parameter)
- **Translation Service**: OpenAI API via Doubao endpoint

## Technical Evidence Analysis

### Issue 1: DialogContent Warning
```
Warning: Missing `Description` or `aria-describedby={undefined}` for {DialogContent}.
```
- Occurs at config load operations (lines 4-6 in import-autosave-works.log)
- Previous fix only addressed translateControl.tsx dialog
- Other DialogContent components still missing accessibility attributes

### Issue 2: Translation Parameter Processing
**Successful Parameter Loading** (lines 17-19):
```
Custom parameters loaded for provider: openai_1753773305649
Header parameters: 0
Body parameters: 1
```

**Correct Parameter Passing** (lines 36-43):
```json
"customParameters": {
  "headerParameters": {},
  "bodyParameters": {
    "thinking": "disabled"
  },
  "configVersion": "1.2.0",
  "lastModified": 1753798405076
}
```

**Translation Failure** (lines 53, 62):
```
批次 1/20 翻译失败，重试 1/1: OpenAI translation failed: Cannot convert undefined or null to object
```

## Root Cause Analysis

### Issue 1: Incomplete DialogContent Fix
- **Root Cause**: Multiple DialogContent components throughout the application, but only one was fixed
- **Scope**: Need to identify and fix all DialogContent instances missing accessibility attributes

### Issue 2: Parameter Processing in OpenAI Service
- **Parameter Structure**: Custom parameters are correctly passed as nested object
- **Integration Gap**: OpenAI service likely expects parameters in different format or has issues processing the nested structure
- **Potential Causes**:
  1. OpenAI service expects flat parameter structure instead of nested headerParameters/bodyParameters
  2. Parameter merging logic in OpenAI service has null/undefined handling issues
  3. API request construction fails when custom parameters are present

## Suspected Components

### Issue 1: DialogContent Components
- Multiple dialog components across the application
- Likely in components using AlertDialog or Dialog from UI library

### Issue 2: OpenAI Service Integration
- `main/service/openai.ts` - Parameter processing and API request construction
- Parameter merging logic for custom parameters with base provider parameters
- API request body construction when custom parameters are present

## Reproduction Steps

### Issue 1 (DialogContent Warning)
1. Open SmartSub application
2. Navigate to any section that triggers config loading
3. Check browser console for accessibility warnings
4. Warning appears consistently during normal operations

### Issue 2 (Translation Failure)
1. Configure custom parameters: `{"thinking": "disabled"}`
2. Ensure parameters are saved (auto-save working correctly)
3. Start translation process with OpenAI provider
4. Translation fails immediately with "Cannot convert undefined or null to object"
5. Error occurs on first batch, then retries and fails again

## Success Confirmation
- **Auto-save Integration**: ✅ Working correctly (lines 36-49 in import-autosave-works.log)
- **Parameter Loading**: ✅ Configuration manager integration successful (lines 17-19 in translation-error.log)
- **Parameter Passing**: ✅ Custom parameters correctly passed to translation provider (lines 36-43)

## Priority Assessment
1. **Critical**: Issue 2 (Translation failure) - Core functionality broken
2. **Low**: Issue 1 (Accessibility warnings) - Compliance issue only

## Next Steps
Ready for analysis phase to investigate:
1. All DialogContent components missing accessibility attributes
2. OpenAI service parameter processing and API request construction logic