# Requirements - Intel OpenVINO GPU Acceleration Integration

## Feature Overview
Add Intel OpenVINO GPU acceleration support to SmartSub, providing Intel GPU users with 3-8x faster subtitle generation while maintaining full backward compatibility with existing CUDA and CPU processing workflows.

## Strategic Alignment

### Product Vision Alignment
- **Privacy-First**: Maintains local processing with no external dependencies
- **Intelligence**: Leverages advanced AI acceleration hardware for faster speech recognition
- **Efficiency**: Provides hardware acceleration for 30%+ additional user coverage (Intel GPU users)
- **Accessibility**: Enables affordable GPU acceleration beyond high-end NVIDIA solutions

### Target User Impact
- **Content Creators**: Faster subtitle generation for Intel GPU-equipped systems
- **Professional Editors**: Additional hardware acceleration option for diverse workflows  
- **Privacy-Conscious Users**: Intel GPU acceleration without cloud dependencies
- **International Creators**: Improved performance for multi-language content processing

## Requirements

### Requirement 1: Multi-GPU Intel Hardware Detection System
**User Story:** As a user with Intel GPU hardware (integrated and/or discrete), I want SmartSub to accurately detect all my Intel GPU options and allow me to choose the optimal one, so that I can benefit from hardware acceleration even in complex multi-GPU scenarios.

#### Acceptance Criteria
1. WHEN SmartSub starts AND Intel GPU hardware is present THEN the system SHALL enumerate all Intel GPU devices (both iGPU and dGPU) with device details
2. WHEN multiple Intel GPUs are detected (Intel Core Ultra iGPU + Intel Arc dGPU) THEN the system SHALL list both options with clear identification
3. WHEN hybrid GPU scenarios exist (Intel iGPU + NVIDIA dGPU) THEN the system SHALL detect both Intel and NVIDIA options independently
4. WHEN Intel GPU enumeration fails or is ambiguous THEN the system SHALL provide user dropdown selection for manual GPU override
5. WHEN Intel GPU is detected BUT OpenVINO toolkit is missing THEN the system SHALL gracefully fallback to CPU processing with clear user notification
6. IF GPU auto-detection makes incorrect selection THEN user SHALL be able to override via settings dropdown with all detected GPU options

#### Implementation Details (Enhanced for Multi-GPU Scenarios)
**File Creation:** `main/helpers/hardwareUtils.ts` (extends `cudaUtils.ts` pattern)

```typescript
// Enhanced Intel GPU Enumeration for Multi-GPU Scenarios
export function enumerateIntelGPUs() {
  try {
    const intelGPUs = [];
    
    if (process.platform === 'win32') {
      // Enumerate all video controllers, not just first match
      const dxdiag = execSync('wmic path win32_VideoController get Name,DeviceID,AdapterRAM', { encoding: 'utf8' });
      const lines = dxdiag.split('\n').filter(line => line.trim());
      
      lines.forEach((line, index) => {
        if (/Intel.*Graphics|Intel.*Xe|Intel.*Arc/i.test(line)) {
          const isIntegrated = /Xe.*Graphics|UHD.*Graphics|Iris.*Xe/i.test(line);
          const isDiscrete = /Arc.*A\d+|Xe.*HPG/i.test(line);
          
          intelGPUs.push({
            id: `intel_gpu_${index}`,
            name: line.trim(),
            type: isDiscrete ? 'discrete' : 'integrated',
            deviceId: `GPU${index}`,
            priority: isDiscrete ? 1 : 2 // Prefer discrete over integrated
          });
        }
      });
    } else if (process.platform === 'linux') {
      // Linux enumeration with device indexing
      const lspci = execSync('lspci -nn | grep -i "VGA.*Intel\\|3D.*Intel"', { encoding: 'utf8' });
      const lines = lspci.split('\n').filter(line => line.trim());
      
      lines.forEach((line, index) => {
        const isIntegrated = /UHD|Xe.*Graphics|Iris/i.test(line);
        const isDiscrete = /Arc|Xe.*HPG/i.test(line);
        
        intelGPUs.push({
          id: `intel_gpu_${index}`,
          name: line.trim(),
          type: isDiscrete ? 'discrete' : 'integrated',
          deviceId: `GPU${index}`,
          priority: isDiscrete ? 1 : 2
        });
      });
    }
    
    // Sort by priority (discrete first, then integrated)
    return intelGPUs.sort((a, b) => a.priority - b.priority);
    
  } catch (error) {
    logMessage(`Intel GPU enumeration failed: ${error}`, 'warning');
    return [];
  }
}

// Comprehensive Multi-GPU Detection
export function detectAvailableGPUs() {
  const intelGPUs = enumerateIntelGPUs();
  const hasOpenVINO = checkOpenVINOSupport();
  
  return {
    nvidia: checkCudaSupport(),
    intel: intelGPUs.filter(gpu => hasOpenVINO), // Only include if OpenVINO available
    intelAll: intelGPUs, // All Intel GPUs for UI dropdown
    apple: isAppleSilicon(),
    cpu: true // Always available
  };
}
```

#### Multi-GPU Scenario Handling
**Intel Core Ultra iGPU + NVIDIA dGPU:**
- Detect Intel Xe Graphics (integrated) + NVIDIA GPU (discrete)
- User preference: NVIDIA CUDA → Intel OpenVINO → CPU
- Settings dropdown: Allow selection between detected options

**Intel Core Ultra iGPU + Intel Arc dGPU:**
- Detect Intel Xe Graphics (integrated) + Intel Arc A-series (discrete)  
- Auto-preference: Intel Arc (discrete) → Intel Xe (integrated) → CPU
- Settings dropdown: Allow selection between Intel GPU options

**GPU Enumeration Priority:**
1. Intel Arc A-series (discrete) - Highest performance
2. Intel Xe Graphics (Intel Core Ultra integrated) - Good performance
3. Legacy Intel UHD/Iris Xe - Basic acceleration

### Requirement 2: OpenVINO Toolkit Integration and Validation
**User Story:** As a user wanting Intel GPU acceleration, I want SmartSub to validate my OpenVINO installation, so that I can use Intel GPU acceleration without complex setup.

#### Acceptance Criteria
1. WHEN OpenVINO toolkit is installed THEN the system SHALL detect OpenVINO version and compatibility with whisper.cpp requirements
2. IF OpenVINO version is incompatible THEN the system SHALL provide clear error messages with specific upgrade guidance
3. WHEN OpenVINO toolkit is missing THEN the system SHALL display installation instructions with download links
4. WHEN OpenVINO detection succeeds THEN the system SHALL enable Intel GPU acceleration options in settings
5. WHEN first run with OpenVINO THEN the system SHALL handle <30s model compilation delay with user feedback

#### Implementation Details (from Implementation Study)
```typescript
// OpenVINO Toolkit Detection
export function checkOpenVINOSupport() {
  try {
    // Check OpenVINO Python bindings or C++ runtime
    const result = execSync('python -c "import openvino; print(openvino.__version__)"', { encoding: 'utf8' });
    const versionMatch = result.match(/(\d+\.\d+)/);
    return versionMatch ? versionMatch[1] : false;
  } catch (error) {
    // Fallback: Check environment variables or installation paths
    return process.env.INTEL_OPENVINO_DIR ? 'env' : false;
  }
}
```

**Version Strategy (from Implementation Study):**
- **Recommended**: OpenVINO 2024.6.0 (per whisper.cpp documentation)
- **Latest**: OpenVINO 2025.2.0 (available but use recommended for stability)
- **Installation**: `pip install openvino==2024.6.0`
- **Build Integration**: whisper.cpp native support (confirmed in PR #1037)
- **First Run Note**: "Slow due to model compilation, cached afterward"

### Requirement 3: Enhanced Dynamic Addon Loading with GPU Priority System
**User Story:** As a user with Intel GPU support, I want SmartSub to automatically select the optimal processing addon, so that I get the best performance without manual intervention.

#### Acceptance Criteria
1. WHEN Intel GPU and OpenVINO are available THEN the system SHALL load the OpenVINO addon for processing
2. WHEN multiple GPU options exist THEN the system SHALL respect configurable user preference settings (NVIDIA → Intel → Apple → CPU)
3. IF OpenVINO addon loading fails THEN the system SHALL fallback to the next available option in priority chain with user notification
4. WHEN addon selection occurs THEN the system SHALL display the selected processing method to the user with performance expectations
5. WHEN addon selection completes THEN the system SHALL log the selected addon path for troubleshooting

#### Implementation Details (from Implementation Study)
**File Modification:** `main/helpers/whisper.ts` - Extend `loadWhisperAddon()` function

```typescript
export async function loadWhisperAddon(model) {
  const platform = process.platform;
  const settings = store.get('settings') || { useCuda: false, useOpenVINO: false };
  const { useCuda, useOpenVINO, gpuPreference } = settings;
  
  let addonPath;
  const gpuCapabilities = detectAvailableGPUs();
  
  // GPU Priority Resolution
  const gpuPriority = gpuPreference || ['nvidia', 'intel', 'apple', 'cpu'];
  
  for (const gpu of gpuPriority) {
    if (gpu === 'nvidia' && platform === 'win32' && useCuda && gpuCapabilities.nvidia) {
      addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon-cuda.node');
      break;
    }
    
    if (gpu === 'intel' && useOpenVINO && gpuCapabilities.intel) {
      addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon-openvino.node');  
      break;
    }
    
    if (gpu === 'apple' && gpuCapabilities.apple && hasEncoderModel(model)) {
      addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon-coreml.node');
      break;
    }
  }
  
  // CPU Fallback
  if (!addonPath) {
    addonPath = path.join(getExtraResourcesPath(), 'addons', 'addon-cpu.node');
  }
  
  const module = { exports: { whisper: null } };
  process.dlopen(module, addonPath);
  return module.exports.whisper;
}
```

**Integration Points:**
- Maintain 100% backward compatibility with existing CUDA and CoreML addon logic
- Add `addon-openvino.node` to extraResources addon distribution
- Implement user-configurable GPU priority system in settings

### Requirement 4: GPU Utilization Logic Extension  
**User Story:** As a user processing subtitles, I want SmartSub to utilize my Intel GPU when beneficial, so that I get faster processing times and better system resource utilization.

#### Acceptance Criteria
1. WHEN Intel GPU acceleration is enabled AND model supports GPU processing THEN the system SHALL use Intel GPU for inference
2. WHEN Intel GPU memory is insufficient THEN the system SHALL fallback to CPU processing with user notification
3. IF Intel GPU processing fails during operation THEN the system SHALL recover gracefully and complete processing with CPU
4. WHEN GPU processing completes THEN the system SHALL report performance metrics and processing time

**Technical Notes:**
- Modify GPU detection logic in `subtitleGenerator.ts` for Intel GPU branch
- Add Intel GPU memory validation before processing large models
- Implement GPU failure recovery with seamless CPU fallback
- Add telemetry for Intel GPU performance tracking

### Requirement 5: Enhanced Settings with GPU Selection Dropdown
**User Story:** As a user with multiple GPU options, I want to manually select my preferred GPU when auto-detection fails or I want to override the automatic selection, so that I have full control over hardware acceleration.

#### Acceptance Criteria
1. WHEN multiple GPU accelerations are available THEN the system SHALL provide dropdown selection UI with all detected GPU options
2. WHEN Intel GPU enumeration detects multiple Intel GPUs THEN the dropdown SHALL list each GPU with clear identification (e.g., "Intel Arc A750 (Discrete)", "Intel Xe Graphics (Integrated)")
3. WHEN auto-selection chooses suboptimal GPU THEN user SHALL be able to override via dropdown selection
4. WHEN user changes GPU preferences THEN the system SHALL apply changes immediately for new processing tasks with validation
5. IF user selects unavailable GPU option THEN the system SHALL validate, provide feedback, and suggest alternatives
6. WHEN settings are saved THEN the system SHALL persist specific GPU selection across application restarts

#### UI Design Requirements
**GPU Selection Dropdown Options:**
```typescript
interface GPUOption {
  id: string;
  displayName: string;
  type: 'nvidia' | 'intel-discrete' | 'intel-integrated' | 'apple' | 'cpu';
  status: 'available' | 'unavailable' | 'requires-setup';
  performance: 'high' | 'medium' | 'low';
  description: string;
}

// Example dropdown options:
[
  { id: 'nvidia_rtx3060', displayName: 'NVIDIA RTX 3060 (CUDA)', type: 'nvidia', status: 'available', performance: 'high' },
  { id: 'intel_arc_a750', displayName: 'Intel Arc A750 (OpenVINO)', type: 'intel-discrete', status: 'available', performance: 'high' },
  { id: 'intel_xe_igpu', displayName: 'Intel Xe Graphics - Core Ultra (OpenVINO)', type: 'intel-integrated', status: 'available', performance: 'medium' },
  { id: 'cpu_fallback', displayName: 'CPU Processing (Fallback)', type: 'cpu', status: 'available', performance: 'low' }
]
```

**Settings Integration:**
- Add `selectedGPUId`, `useOpenVINO`, and `gpuAutoDetection` to existing Electron Store
- Create intuitive UI components for GPU selection in settings page  
- Implement real-time validation with user-friendly error messages
- Maintain backward compatibility with existing `useCuda` setting
- Add "Auto-detect (Recommended)" option alongside manual selection

### Requirement 6: Build System and Distribution
**User Story:** As a user installing SmartSub, I want access to Intel GPU acceleration without additional build complexity, so that I can use the feature immediately after installation.

#### Acceptance Criteria
1. WHEN SmartSub releases are built THEN OpenVINO addon variants SHALL be included for Windows and Linux
2. WHEN user downloads SmartSub THEN the appropriate OpenVINO addon SHALL be automatically selected based on platform
3. IF OpenVINO addon is not compatible with user system THEN the system SHALL fallback to CPU processing
4. WHEN new OpenVINO versions are released THEN build system SHALL support updates without breaking changes

**Technical Notes:**
- Extend `.github/workflows/release.yml` build matrix for OpenVINO variants
- Build OpenVINO addons for Windows (Win10/11) and Linux (Ubuntu 20.04/22.04)
- Use whisper.cpp recommended OpenVINO 2024.6.0 for stability
- Implement automated testing for OpenVINO addon loading

### Requirement 7: Error Handling and User Experience
**User Story:** As a user encountering Intel GPU issues, I want clear error messages and recovery options, so that I can resolve problems or use alternative processing methods.

#### Acceptance Criteria
1. WHEN Intel GPU detection fails THEN the system SHALL provide diagnostic information and suggested solutions
2. WHEN OpenVINO toolkit issues occur THEN the system SHALL guide users to resolution steps
3. IF Intel GPU processing encounters errors THEN the system SHALL recover gracefully and continue processing
4. WHEN hardware compatibility issues exist THEN the system SHALL provide clear compatibility requirements

**Technical Notes:**
- Implement comprehensive error handling for Intel GPU driver compatibility
- Provide user-friendly error messages with actionable resolution steps  
- Create diagnostic logging for Intel GPU and OpenVINO troubleshooting
- Implement automatic fallback chain: Intel GPU → NVIDIA GPU → CPU

### Requirement 8: Development Environment Compatibility
**User Story:** As a developer working on macOS, I want to develop and test Intel GPU features effectively, so that I can deliver quality functionality despite not having Intel GPU hardware.

#### Acceptance Criteria
1. WHEN developing on macOS THEN Intel GPU detection SHALL be mockable for testing
2. WHEN Intel GPU features are unavailable THEN development tools SHALL simulate Intel GPU scenarios
3. IF OpenVINO toolkit is not installed on macOS THEN development SHALL continue with appropriate mocking
4. WHEN running automated tests THEN Intel GPU code paths SHALL be testable without Intel hardware

**Technical Notes:**
- Implement mock Intel GPU detection for macOS development environment
- Create test doubles for OpenVINO toolkit detection and addon loading
- Add development-only flags for simulating Intel GPU scenarios
- Ensure CI/CD pipeline can test Intel GPU code paths without Intel hardware

## Compatibility Requirements (Primary Focus)

### Hardware Compatibility Standards
**Primary Requirement:** Ensure whisper models run reliably on Intel hardware with OpenVINO acceleration.

**Compatibility Validation (Higher Priority than Speed):**
- **Intel Core Ultra (Xe Graphics)**: Stable subtitle generation without crashes
- **Intel Arc A-series**: Consistent performance across all Arc models (A310-A770)
- **OpenVINO Integration**: Seamless toolkit detection and initialization
- **Multi-GPU Scenarios**: Proper enumeration and selection in hybrid systems
- **Fallback Reliability**: 100% CPU fallback success when Intel GPU fails

### Resource Management Requirements
```yaml
gpu_memory: Adaptive allocation based on available Intel GPU memory
system_memory: Monitoring with automatic fallback if insufficient  
thermal_management: Respect system thermal limits
driver_compatibility: Graceful handling of driver version mismatches
```

### Performance Expectations (Secondary Priority)
*Note: Performance is secondary to compatibility and reliability*

**General Performance Expectations:**
- **Intel Arc A-series**: Noticeable acceleration over CPU processing
- **Intel Core Ultra (Xe)**: Some acceleration benefit over CPU processing
- **Memory Usage**: Reasonable overhead without system impact
- **Startup Time**: Acceptable OpenVINO initialization delay on first run

**Validation Focus:**
- **Functionality First**: Subtitle generation completes successfully
- **Stability**: No crashes or memory leaks during processing
- **User Experience**: Clear feedback and error handling
- **Speed**: Performance improvement is secondary to reliability

### Platform Compatibility Matrix (Intel-Focused)
**Primary Target Hardware:**
- **Intel Core Ultra Processors**: Xe Graphics (integrated) - Main compatibility focus
- **Intel Arc A-Series**: A310, A380, A580, A750, A770 (discrete) - High-performance target

**Platform Support:**
- **Windows 10/11**: Intel GPU driver 31.0.101.4146+ (required for OpenVINO compatibility)
- **Linux Ubuntu 20.04/22.04 LTS**: Mesa 23.0+ and kernel 5.15+ (Intel Arc and Xe support)

**Hardware Priority (Based on User Adoption):**
1. **Intel Core Ultra iGPU (Xe Graphics)** - Most common, integrated in modern Intel CPUs
2. **Intel Arc A-series dGPU** - High-performance discrete cards for enthusiasts
3. **Legacy Intel Graphics** - UHD Graphics, Iris Xe (limited OpenVINO benefit)

## Technical Constraints

### Development Environment
- **macOS Development**: No direct Intel GPU testing capability - requires simulation/mocking
- **Cross-Platform Builds**: Windows and Linux target platforms for Intel GPU support
- **Testing Strategy**: Automated testing with mocked Intel GPU detection on macOS

### Integration Requirements
- **Backward Compatibility**: Full compatibility with existing CUDA and CPU processing
- **Settings Migration**: Seamless upgrade path for existing users
- **Build Complexity**: Manageable increase in CI/CD build matrix and artifact storage

### Framework Alignment
- **whisper.cpp Integration**: Use existing whisper.cpp OpenVINO support (PR #1037)
- **Electron Architecture**: Maintain existing main/renderer process communication patterns
- **TypeScript Coverage**: Full type safety for all new Intel GPU functionality

## Risk Assessment (from Implementation Study)

### Technical Risks and Mitigation Strategies
| Risk | Probability | Impact | Mitigation Strategy |
|------|-------------|--------|-------------------|
| Intel GPU driver compatibility | Medium | High | Version detection + graceful fallback + clear error messaging |
| OpenVINO toolkit availability | Low | High | Runtime detection + clear error messages + installation guidance |
| Build matrix complexity | High | Medium | Incremental rollout + automated testing + build optimization |
| Performance regression | Low | Medium | Comprehensive benchmarking + performance monitoring |
| Memory usage increase | Medium | Medium | Memory profiling + configurable limits + resource cleanup |

### Implementation Phases (6-8 Week Timeline)

#### Phase 1: Foundation (Week 1-2) - LOW RISK
```yaml
scope: Core detection & validation system
deliverables:
  - hardwareUtils.ts (Intel GPU + OpenVINO detection)
  - Unit tests for detection logic
  - Documentation updates
effort: 16-24 hours
risk: Low
```

#### Phase 2: Runtime Integration (Week 3-4) - LOW-MEDIUM RISK  
```yaml
scope: Addon loading & GPU utilization logic
deliverables:
  - Enhanced whisper.ts addon selection
  - Modified subtitleGenerator.ts GPU logic
  - Integration tests
effort: 24-32 hours  
risk: Low-Medium
```

#### Phase 3: Build System (Week 5-6) - MEDIUM-HIGH RISK
```yaml
scope: Build matrix & distribution
deliverables:
  - Enhanced release.yml workflow
  - OpenVINO addon builds  
  - Automated testing
effort: 32-48 hours
risk: Medium-High
```

#### Phase 4: Optimization & Release (Week 7-8) - LOW RISK
```yaml
scope: Performance tuning & production readiness
deliverables:
  - Performance optimizations
  - User documentation
  - Production deployment
effort: 16-24 hours
risk: Low
```

## Development Strategy: Git Worktree Approach (from Implementation Study)

### macOS Development Solution
**Problem**: Avoid affecting current codebase during OpenVINO development on macOS (no Intel GPU hardware)
**Solution**: Use `git worktree` for isolated development with shared Git history

```bash
# Setup isolated development environment
git worktree add ../smartsub-openvino-dev feature/openvino-integration
cd ../smartsub-openvino-dev

# Development workflow:
# 1. Implement OpenVINO features in worktree
# 2. Test thoroughly in isolation with mocking
# 3. Merge back to main when stable
# 4. Remove worktree: git worktree remove ../smartsub-openvino-dev
```

**Advantages:**
- **Isolation**: Zero impact on main codebase
- **Parallel Development**: Main development continues uninterrupted  
- **Easy Switching**: `cd` between environments instantly
- **Shared Git State**: Branches, commits, remotes all synchronized
- **Risk Mitigation**: Failed experiments don't affect production

## Success Criteria

### Functional Success (Implementation Study Validated)
- Intel GPU detection accuracy >98% on compatible hardware
- OpenVINO addon loading success rate 100% when toolkit is properly installed  
- Graceful fallback to CPU processing in 100% of GPU failure scenarios
- Settings persistence and preference management working across all platforms
- Consecutive runs without crash: >100 (sustained operation)
- Memory leak prevention: <1% memory growth over 10 runs

### Compatibility Success (Primary Success Criteria)
- Intel Core Ultra (Xe Graphics) stable subtitle generation: 100% success rate
- Intel Arc A-series reliable processing: All models (A310-A770) supported
- Multi-GPU enumeration accuracy: >95% correct detection of Intel GPUs
- Hybrid system compatibility: Intel iGPU + NVIDIA dGPU scenarios handled correctly
- OpenVINO integration reliability: Seamless toolkit detection and initialization
- User dropdown override: Manual GPU selection works in 100% of cases

### Performance Success (Secondary Success Criteria)
*Note: Performance metrics are secondary to compatibility achievements*
- Functional acceleration: Any measurable improvement over CPU baseline acceptable
- System stability: No performance regression for existing CUDA/CPU users
- Memory efficiency: Reasonable resource usage without system impact
- User experience: Acceptable initialization times and clear progress feedback

### Quality Success (Implementation Study Standards)
- Zero breaking changes to existing CUDA/CPU users
- Comprehensive error handling with actionable user guidance
- Full automated test coverage for Intel GPU code paths including macOS mocking
- Documentation and user guides for Intel GPU setup and troubleshooting
- Cross-platform consistency: Windows 10/11 + Ubuntu 20.04/22.04
