# Project Structure - SmartSub

## Directory Organization

### Root Level Structure
```
SmartSub/
├── main/                 # Electron main process
├── renderer/             # Next.js renderer process  
├── types/               # Shared TypeScript definitions
├── extraResources/      # Native addons and ML models
├── resources/           # Static application resources
├── docs/               # Documentation website (Docusaurus)
├── Project/            # Project management and specs
└── scripts/            # Build and utility scripts
```

## Core Directories

### Main Process (`main/`)
**Purpose**: Electron main process handling system operations, file processing, and business logic

```
main/
├── background.ts           # Application entry point and window management
├── preload.ts             # Secure API bridge to renderer process
├── helpers/               # Core business logic modules
│   ├── audioProcessor.ts      # Audio file processing utilities
│   ├── subtitleGenerator.ts   # Whisper integration and subtitle generation
│   ├── taskManager.ts         # Concurrent task processing
│   ├── ipcHandlers.ts         # IPC communication handlers
│   └── store/                 # Application state management
├── service/               # Translation service implementations
│   ├── baidu.ts              # Baidu Translation API
│   ├── openai.ts             # OpenAI-style API integration
│   └── [provider].ts         # Other translation providers
└── translate/             # Translation orchestration
    ├── services/             # Translation service abstractions
    ├── types/               # Translation-specific types
    └── utils/               # Translation utilities
```

### Renderer Process (`renderer/`)
**Purpose**: Next.js frontend providing the user interface

```
renderer/
├── components/            # React UI components
│   ├── ui/                   # Base UI components (shadcn/ui)
│   ├── subtitle/             # Subtitle-specific components
│   ├── TaskList.tsx          # Task management interface
│   └── [Feature]Form.tsx     # Feature-specific forms
├── hooks/                # Custom React hooks
│   ├── useIpcCommunication.tsx  # IPC communication hook
│   ├── useFormConfig.tsx        # Form state management
│   └── useSubtitles.ts          # Subtitle management hook
├── pages/                # Next.js pages
│   ├── [locale]/             # Internationalized routes
│   │   ├── home.tsx             # Main application interface
│   │   ├── settings.tsx         # Configuration interface
│   │   └── modelsControl.tsx    # Model management interface
│   └── _app.tsx              # Application root component
├── lib/                  # Utilities and configurations
│   ├── utils.ts              # Common utility functions
│   ├── store.ts              # Client-side state management
│   └── models.json           # Model configuration data
├── public/locales/       # Internationalization files
│   ├── en/                   # English translations
│   └── zh/                   # Chinese translations
└── styles/               # Global styles
    └── globals.css           # Tailwind and custom styles
```

### Shared Types (`types/`)
**Purpose**: Centralized TypeScript type definitions

```
types/
├── index.ts              # Main type exports
├── provider.ts           # Translation provider types
└── types.ts              # Application-specific types
```

## File Naming Conventions

### Components
- **Format**: PascalCase for React components
- **Examples**: `TaskList.tsx`, `SubtitleProofread.tsx`, `ProviderForm.tsx`
- **Pattern**: `[Feature][Component].tsx` for specific functionality

### Hooks
- **Format**: camelCase starting with "use"
- **Examples**: `useFormConfig.tsx`, `useIpcCommunication.tsx`
- **Pattern**: `use[Functionality].tsx`

### Services and Utilities
- **Format**: camelCase for functions and utilities
- **Examples**: `audioProcessor.ts`, `subtitleGenerator.ts`
- **Pattern**: `[domain][Action].ts`

### Configuration Files
- **Location**: Root level for global configuration
- **Examples**: `package.json`, `tsconfig.json`, `nextron.config.js`
- **Pattern**: Standard naming conventions for each tool

## Code Organization Patterns

### Component Structure
```typescript
// Component file structure
import { dependencies } from 'libraries'
import { CustomHook } from '@/hooks'
import { UIComponent } from '@/components/ui'

interface ComponentProps {
  // TypeScript interface definition
}

export function Component({ props }: ComponentProps) {
  // Hook usage
  // Component logic
  // Return JSX
}
```

### Service Implementation Pattern
```typescript
// Service file structure
import { BaseService } from '@/types'
import { utilities } from '@/utils'

export class ServiceName implements BaseService {
  // Configuration
  // Public methods
  // Private utilities
}
```

### Hook Implementation Pattern
```typescript
// Hook file structure
import { React hooks } from 'react'
import { utilities } from '@/lib'

export function useFeatureName() {
  // State management
  // Side effects
  // Return API
}
```

## Import Organization

### Import Order
1. **External libraries**: React, Next.js, third-party packages
2. **Internal utilities**: @/lib, @/utils imports
3. **Components**: @/components imports
4. **Types**: Type-only imports
5. **Relative imports**: Local file imports

### Path Aliases
```json
{
  "@/*": ["./renderer/*"],
  "@/components/*": ["./renderer/components/*"],
  "@/hooks/*": ["./renderer/hooks/*"],
  "@/lib/*": ["./renderer/lib/*"]
}
```

## Configuration Management

### Application Configuration
- **Electron Store**: Persistent user settings and preferences
- **Environment Variables**: Build-time configuration
- **Config Files**: Tool-specific configuration (Prettier, TypeScript, etc.)

### Internationalization Structure
```
public/locales/
├── en/
│   ├── common.json          # Shared translations
│   ├── home.json           # Home page translations
│   ├── settings.json       # Settings page translations
│   └── [page].json         # Page-specific translations
└── zh/
    └── [same structure]    # Chinese translations
```

## Build and Development

### Development Scripts
```json
{
  "dev": "nextron",              # Development mode
  "build": "nextron build --no-pack",  # Build without packaging
  "build:local": "nextron build",      # Full local build
  "format": "prettier --write ."       # Code formatting
}
```

### Asset Management
- **Static Assets**: `/public` and `/resources` directories
- **Dynamic Assets**: Model files in `/extraResources`
- **Build Assets**: Generated in `/app` and `/dist` directories

## Quality Standards

### File Organization Principles
1. **Separation of Concerns**: Clear boundaries between main/renderer processes
2. **Feature Grouping**: Related functionality grouped together
3. **Consistent Naming**: Predictable file and directory naming
4. **Scalable Structure**: Easy to add new features and components

### Code Organization Standards
1. **Single Responsibility**: Each file has a clear, focused purpose
2. **Consistent Imports**: Standardized import organization and aliases
3. **Type Safety**: Comprehensive TypeScript coverage
4. **Documentation**: Clear component and function documentation